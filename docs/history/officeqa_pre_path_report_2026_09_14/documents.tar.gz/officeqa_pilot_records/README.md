# OfficeQA grounded-reward pilot — records and critical review

Pilot date: **2026-09-13**. Final review cut-off: **2026-09-14 10:58:22 UTC**.
Broad execution plan: `docs/officeqa_rl_plan.md`. Immediate detailed implementation:
`docs/officeqa_rgate_recovery_plan.md`. Next-agent entry point:
`docs/officeqa_rgate_handoff.md` (all paths repository-relative).

> **Status: NO-GO for grounded-policy optimization.** Air/82 attempt 4 is complete
> and FAILED: **16/80 labeled controls accepted, 5/242 labeled negatives accepted,
> case upper95 4.295%, base-ID upper 7.414%**. The labels themselves are uncertified
> and sometimes incorrect; literal-value matching caused 55 control rejections.
> Do not interpret this as a nearly cleared gate. The new recovery contract is a
> plan, not implemented code. Preserve the historical artifacts and unrelated edits.
>
> Final review, reports, code snapshots, exact-hash bundles and portable reproducers:
> `officeqa_pilot_records/rgate_review_2026_09_14/`.

## Update 2026-09-13 — reward/sandbox repairs, R-gate smoke, reproducibility finding

Historical state after the first repairs; the **2026-09-14 final review supersedes
these readiness claims**. Passing the listed tests did not cover the later reproduced
authority, unit, label, group-admission and runner-integrity failures:
- **Reward repaired further after critical review** (strict full-input answer grammar,
  affirmative-support eligibility, assistant-only answer commitment, failed-read/forged-output
  evidence checks). Current CPU contract: `test_reward_contract.py` **43/43**.
- **Compute boundary changed from audit hooks to bubblewrap** after both in-process designs were
  escaped. The child has no network and cannot see `/Volumes`, `/home`, the repo, model files, or
  benchmark data. Local contract: **11 pass, 2 pandas-dependency skips**; v7 is pushed/registered,
  and df1 `air/80` run 510519807483794 proved the compute-tool bwrap variant works with network denied.
- **R-gate smoke (`air/79`, run 340221642696128):** the real GLM-5.3 judge saw the whole
  trajectory and recognized several planted wrong routes, but the saved result is **8 resolved +
  1 unknown**, not 9/9. RG06 predates the parser fix and needs replay; valid alternative source
  RG07 was accepted but discounted to **0.925**. This remains far short of the statistical gate.
- **Reproducibility:** `air/71` and `air/72` do NOT reproduce per-UID (76/246 predictions diverge,
  full-set McNemar 37 discordant) despite near-equal aggregates. On the 133 hard questions the
  pinned-scorer table is 6 both / 10 air-71-only / 8 air-72-only / 109 both-wrong (16→14,
  illustrative paired SE≈3.2pp). Repeated evaluations and same-question paired tests are required;
  do not describe this as 37 questions of uncertainty on the hard-set delta.
  → `air71_vs_air72.reconcile.json`.

New artifacts here (derived, additive; historical records unchanged): `rgate_scores.jsonl`,
`officeqa_base_air71.json`, `air71_vs_air72.reconcile.json`, `officeqa_traces.measure.json`.

## Final update 2026-09-14 UTC — air/82 complete; recovery required

All reviewed jobs are terminal at the final API check. Attempt 1 failed on a scorer
import-path bug. Attempts 2/3/4 scored their complete bundles and then failed thresholds:

| Air/82 run | Cases | Labeled positives accepted | Labeled negatives accepted | Case upper95 |
|---|---:|---:|---:|---:|
| 657777974855885 (attempt 2) | 317 | 78/80 | 121/220 | 60.668% |
| 591895497446045 (attempt 3) | 317 | 63/80 | 72/220 | 38.312% |
| **543029753940588 (attempt 4)** | **339** | **16/80** | **5/242** | **4.295%** |

Attempt 4 has 11/339 UNKNOWN rewards and 0/17 nonzero wrong-answer rewards. Its report
was generated at 2026-09-14T05:54:57Z. **55 of its 62 scored control rejections came
from literal gold-in-quote matching**; only 1/26 alternate-source controls was accepted.
The preceding CPU frozen-verdict replay predicted the regression direction (18/80);
the actual completed GPU result is 16/80.

**The prior diagnosis was too confident.** Mutation labels are not ground truth:
operands/alternate representations survive answer-string deletion; later correct reads
survive early swaps; fake backward-dated filenames were labeled valid alternatives;
wrong/abstaining/format-invalid original answers were labeled wrong retrieval routes.
All G substrates also inherit historical 3,000-character logging loss. The aggregate
rates above are not independently established real grounding error rates.

All five latest accepted negatives were inspected. UID0002_N2 retains a later correct
507 row. UID0148_T had correct numeric/list values and existing calculations despite
benchmark/format selection. UID0204_T retains the reported 1.47 and 1.3 inputs for
0.17. UID0189_R2 exposes missing source-period coverage for two 13-month medians.
UID0122_T needs category/shortcut adjudication: common CPI scaling cancels, but euro+yen
produces 0.953 pp while including receivables produces 0.946 pp. Do not relabel cases
merely to agree with the judge or claim the five are all clean false accepts.

**Training progress retained:** run **616024033111491** completed two real answer-mode
optimizer steps after fixing the 8<16 prompt-group batching issue and the later 147k
OOM/false-green exit guard. It used 32 real easy questions, four siblings/group,
MAX_TURNS=8, a ~73k budget and std-normalization OFF. This is an integration proof,
not learning or grounded-reward validation; `save_freq=-1` did not prove checkpoint writing.

**Quarantine claim narrowed:** sentinel/sitecustomize activation was seen, but outer
manager timeouts still become ordinary zero rewards; advantage zeroing does not remove
KL or denominator effects. Actual pre-batch whole-group admission, typed outcomes,
bounded refill and async credit handling remain unimplemented.

**Next:** implement the recovery plan's R1–R9 contracts and CPU gates before another
full judge run. Keep graded reward and the full GLM-5.3 TP16 model; accept genuine
alternative proofs, not fabricated filenames. Rebuild certified real-easy labels and
actor-visible ledgers; repair units, proof computation, transport, group admission,
runner integrity and independent validation. The 317/339 bundles are development
artifacts, not locked statistical validation. Complete records and portable reproduction
are in `rgate_review_2026_09_14/`; no historical JSONL was overwritten.

## What this pilot attempted to test

Can an answer-gated, process-aware reward distinguish a supported correct answer
from a *lucky wrong-route* answer: the right number obtained from the wrong table,
row, period, unit, or incomplete evidence?

Base-35B trajectories were scored using file-engagement heuristics plus a
self-hosted GLM-5.3 route auditor at TP16. The 100-record sample contains all
**51 correct under the legacy local scorer** plus 49 sampled wrong answers.
It is not a representative correctness sample or a set of same-question GRPO groups.

## Files

These records are currently **untracked** validation artifacts, not implementation code.

| File | What |
|---|---|
| `officeqa_traces.jsonl` | 246 base-35B trajectories from `air/72`: question, gt, pred, source files, reasoning, calls, and **lossy** tool outputs. Outputs were cut at 3,000 characters during recording. |
| `officeqa_grounded_scores_v1.jsonl` | 100 historical reward records before the pilot fixes. |
| `officeqa_grounded_scores_v2.jsonl` | 100 historical reward records after those fixes; authoritative **v2 rerun**, not a training-ready reward. |
| `officeqa_grounded_scores.jsonl` | Same as v1, retained for reference; do not confuse it with v2. |
| `validation_report.txt` | Historical human-readable v1 report. |
| `validation_report_v2.txt` | Historical v2 report: 15 rescored cases, lower-confidence cases, and wrong samples with judge reasoning. Its optimistic conclusions are superseded by this review. It is **not independent human ground truth**. |

Score records contain:
`{uid, question, gt, pred, answer_correct, source_files, reward, reward_reason,
grounding{source_identity, files_pulled, trajectory_quality, ...},
judge_verdict{verdict, route_score, targeted_right_category,
retrieved_all_components, answer_supported_by_retrieved_cells, reason}}`.

## Historical result: v1 → v2

| Metric | v1 | v2 |
|---|---:|---:|
| Judge verdict parsed by the permissive parser | 62/100 | 99/100 |
| Legacy-correct records receiving the 0.05 “lucky” floor | 15/51 | 0/51 |
| Mean reward on legacy-correct records | 0.688 | 0.956 |

**Exact v2 route distribution for the 51 correct records:**
14×1.00, 8×0.95, 17×0.90, 10×0.85, 1×0.80, 1×0.50.
The previous 0.8/0.9 counts were rounded bins, not exact scores.

There are **50 `grounded` verdicts and one `wrong_but_reasonable`** among correct
answers. All 51 have support=true, while 50 have completeness=true. No record
received `lucky_wrong_source`. A nonconstant route score does **not** establish
sensitivity to the wrong-evidence/correct-number failure this reward targets.

**Useful fixes retained:**
1. Gold filenames are not exhaustive: other bulletins can republish the same
   historical series. The hard file-miss gate was removed and 15 previously floored
   records were rescored. Whether every rescue has valid category, vintage,
   qualifiers, and derivation still needs independent source-level review.
2. `reasoning_effort=high`, a 10,240-token completion budget, and broader parsing
   improved parsed responses from 62 to 99. Parsing success is not semantic validity;
   malformed-field defaults and failure handling remain unsafe.

## Historical findings from the first pilot review (2026-09-13)

Some early bugs below were subsequently repaired; others have stronger counterexamples
in the finalized 2026-09-14 archive. Treat this section as versioned history, not a
claim that the current production contract is approved.

### 1. The baseline diagnosis needs correction

The saved 246 traces score **13/133 hard (9.8%)**, 38/113 easy, and 51/246 overall
with the legacy scorer. They contain:
- **158 explicit `DATA NOT AVAILABLE` answers**, including 97 hard questions;
- 12 missing extracted answers, including nine hard questions;
- only 76 substantive attempted answers, including 27 hard questions;
- 179 trajectories reaching the 16-turn cap, including 110 hard questions.

This is not predominantly a “wrong numerical answers rather than abstention”
baseline. The original `air/71` report of 12.0% hard must be reconciled at the UID
level; matching 51/246 totals do not prove the trace run reproduced that baseline.

The upstream scorer snapshot inspected during review gives 52/246 overall and
14/133 hard on these same predictions by fixing UID0148's list parsing. That is
**scorer drift, not learning**. The plan records the snapshot hash; neither the
project's scorer nor these historical records was changed by this review.

### 2. The judge did not see complete evidence

Every saved trajectory contains an output clipped at 3,000 characters; 1,987/3,335
outputs hit that cap. The judge additionally received only a 12,000-character
head/tail rendering: **47/51 correct trajectories** exceed that window.

For example, UID0167's judge reason acknowledges that a required 1950 read is in
the omitted portion, yet marks all components retrieved and supported. This does
not prove the original answer was ungrounded; it shows the judge approved evidence
it could not inspect. Agent explanations must not substitute for missing observations.

### 3. Reward and safety blockers were reproduced

- The local “exact” scorer accepts extra answer candidates, reversed lists,
  mismatched explicit units, and other malformed numerical answers.
- A correct number plus a **failed gold-file read or no-match grep** receives
  **reward 1.0 on judge failure**. Requested filenames are not supporting evidence.
- Under default standard-deviation-normalized GRPO, `[0, 0, 0, 0.05]` and
  `[0, 0, 0, 1]` produce nearly identical advantages. The lucky floor can still
  strongly reinforce the only positive rollout; tiny route-score differences can
  also dominate all-correct groups.
- `OQ_REWARD_MODE=answer` still executes the grounding formula: it is not the
  advertised answer-only control. Structured versus equivalent XML traces also
  produce different hygiene reports.
- A harmless temporary-file probe escaped the compute tool's purported filesystem
  restriction. Actual process/container isolation is required before optimization;
  no host secrets or training gold were accessed in the probe.

See the plan for exact code locations, additional parser/tool issues, validation
criteria, and the distinction between reproduced CPU findings and untested GPU integration.

## Revised reward direction

Replace subjective transcript grading with a small **verifiable evidence and
calculation submission**:
1. Strictly parse the one committed answer, including arity/order, units and rounding.
2. Bind facts to authentic, actor-visible source cells and their headers/periods.
3. Recompute a bounded derivation deterministically; use a blinded semantic auditor
   only for unresolved meaning or source equivalence.
4. Preserve the owner's **graded reward for correct + verified support**; wrong or
   invalid evidence receives exactly zero. Verifier outages/uncertainty trigger retry
   and whole-group exclusion, never file-based success. The typed recovery formula
   and failure taxonomy are specified in `docs/officeqa_rgate_recovery_plan.md`.
5. Accept valid alternative sources and derivations, not just the generator's one
   proof. Preserve vintage/qualifier constraints when the question requires them.

## How to validate next

- Read `validation_report_v2.txt` as a historical inspection aid, not as labels.
  Check source evidence for the rescored cases and explicitly adjudicate UID0002's
  composition qualifiers and examples whose evidence was omitted from the judge input.
- Regenerate lossless **actor-visible** traces after tool/cursor/header repairs;
  save to a new versioned artifact, rather than overwriting this bundle.
- Build a blinded, independently labeled suite of matched correct/wrong-evidence
  cases, including alternate valid sources, revisions, missing inputs, forged outputs,
  prompt injection, padding, malformed verdicts, and judge outages. One planted
  lucky rejection is necessary evidence, not a sufficient validation gate.
- Test actual training serialization and **group advantages**, not just offline
  average rewards. Fix the control mode before comparing reward designs.
- Use certified existing easy questions first; synthetic question generation is
  deferred. After the necessary gates, compare SFT-only, typed-answer-only RL and
  graded verified-support RL under the same frozen controller. Additional independent
  tasks are required for the full statistical claim; repeated variants do not supply them.

Artifact hashes and checked primary references are in `docs/officeqa_rl_plan.md` §11.
