# OfficeQA R-gate — next-agent handoff

**Read this first.** Handoff cut-off: **2026-09-14 10:58:22 UTC**.
Repository: `/home/michael.shtelma/verl-on-air`.

## 1. Current decision and user mandate

The user requested an ultra-detailed implementation plan, inclusion of the latest air/82
failure, a finalized review, updated project documentation and a handoff another agent
can use. Those review/planning/archive tasks are complete. **The recovery code has not
been implemented.** Confirm the next implementation mandate rather than mistaking this
handoff for completed repairs.

**NO-GO for grounded-policy optimization, a full-scale RL run or bulk synthesis.**
The next work is CPU-first contracts/regressions/label certification, not another unchanged
GPU judge iteration. Previous GPU permission does not bypass these technical gates.

Owner preferences to preserve:

- Graded reward, not a mandatory binary reward. Invalid remains exactly zero.
- Full GLM-5.3 TP16 judge, not a smaller substitute.
- Keep bubblewrap and numpy/pandas/scipy in the agent compute tool.
- Use existing real easy questions now; no mass synthetic-question generation.
- Preserve historical JSONL and all unrelated uncommitted work; **do not commit unless asked**.
- Distinguish CPU source/probe findings, installed-image tests, GPU execution and learning.
- A successful job/printed patch activation is not proof of reward safety or learning.

## 2. Where the authoritative material lives

Read in this order:

1. `officeqa_pilot_records/rgate_review_2026_09_14/README.md` — finalized evidence-based
   review, including every accepted negative in attempt 4.
2. `docs/officeqa_rgate_recovery_plan.md` — detailed R0–R11 implementation packages,
   schemas, algorithms, file map, test matrix, acceptance criteria and GPU ladder.
3. `docs/officeqa_rl_plan.md` — broader M/S/D/R/L/T/E plan, corrected current status,
   baseline history and scale gates. The recovery plan supersedes its old immediate
   prompt-tuning/readiness claims.
4. `officeqa_pilot_records/README.md` — historical pilot overview with final update.

The working tree is intentionally uncommitted. A clean checkout of the old git HEAD is
not this handoff: it would omit substantial pre-existing code and the new archive/docs.
Inherit the working directory or explicitly transfer the complete relevant uncommitted
state. `working_tree_at_review.txt` in the archive records the pre-document-update state.

## 3. Latest jobs — no pending result among the reviewed runs

Jobs API was rechecked at the handoff cut-off:

| Run | Status | Meaning |
|---|---|---|
| **543029753940588** | **FAILED, terminal** | air/82 attempt 4 completed 339-case scoring and failed thresholds |
| 591895497446045 | FAILED, terminal | attempt 3 completed 317-case scoring and failed thresholds |
| 657777974855885 | FAILED, terminal | attempt 2 completed 317-case scoring and failed thresholds |
| 878119239646411 | FAILED, terminal | attempt 1 had a scorer import bug after judge startup |
| 616024033111491 | SUCCESS, terminal | answer-mode smoke completed two optimizer steps |

No claim is made about unrelated workspace jobs. Do not keep polling these completed
runs expecting a new result. `run_statuses/summary.json` in the archive holds the check.
The workspace's peer-node nonzero-exit message for attempts 2/3/4 is the consequence of
the gate's exit 1, not evidence of a CUDA/optimizer crash in those judge jobs.

Earlier useful runs: sandbox 510519807483794; prep-32 391307965007953; initial
8-question smoke 255793754949568 had no optimizer batch; 32-question/16-turn run
805654108465557 formed a batch but OOM'd and was incorrectly reported green by its
old log-based exit guard. Run 616024033111491 repaired that integration at eight turns.

## 4. The latest air/82 result and what it teaches

Attempt 4 report generated **2026-09-14T05:54:57Z**, scoring elapsed 1,580.7 seconds:

- 339/339 scored; 80 labeled positives, 242 labeled negatives, 17 wrong gates.
- **16/80 controls accepted (20%)**; 62 scored rejections, two unknown.
- **55** control rejections caused by the literal-gold-in-quote rule; four period
  checks, two negative judge verdicts, one anachronism.
- Only **1/26 alternative-source controls** accepted.
- **5/242 labeled negatives accepted (2.066%)**; case upper95 **4.295%**, nominal
  base-ID upper **7.414%**. Both main thresholds FAIL.
- UNKNOWN 11/339 (3.245%); wrong-gate nonzero 0/17.

The prior CPU replay accepted 18/80 using frozen attempt-3 judgments; do not confuse
that ablation with the actual 16/80 GPU result. Negative bundles changed, so raw
aggregate reductions do not isolate model/checker improvements.

Five accepted-negative anchors:

1. **UID0002_N2:** an early cell is swapped but step 11 still contains the correct 507
   row/header. Negative label is not justified by the mutation.
2. **UID0148_T:** original `28,2444.28` has correct values under the strict list parser
   but was selected as wrong by the benchmark-based generator; original compute already
   produces count 28 and mean 2444.28. Format/answer errors are not retrieval labels.
3. **UID0204_T:** requested sources retain 1.47 and 1.3 trillion; reported-value subtraction
   is 0.17. The original 0.18 does not erase a valid route in the evidence.
4. **UID0189_R2:** two 13-month medians credited despite missing source-month coverage in
   the saved view; compute-authored arrays do not authenticate those inputs. Historical
   clipping means the original actor's full view is unknown.
5. **UID0122_T:** CPI scaling cancels within a share. Euro+yen gives 0.953 pp; including
   receivables gives 0.946 pp. Original-page category/hierarchy adjudication remains
   required. Do not validate a derivation just because a judge says it matches gold.

Do NOT relabel all five automatically or interpret all as clean judge errors. The
source-view, target semantics and mutation labels need independent certification.

## 5. Blocking implementation facts

- Production `officeqa_grounded_reward.py` is still the unsafe v2.1 code. It searches
  raw gold strings in evidence and derives composition from source-file count.
- Offline quote evidence includes compute stdout. Training uses the whole flat solution;
  fake printable markers can manufacture authority. Pinned rate_limited decoding strips
  special role tokens. A real read-only episode scores differently through the two paths.
- Current strict parsing accepts wrong percent/added-scale cases without TaskSpec.
- `(no matches found)` injected read bodies can be counted as successful reads.
- Year matching mistakes ranges, footnotes and line numbers for observation periods.
- Outer reward-manager timeouts become ordinary zero despite sentinel quarantine.
  Advantage zeroing does not remove KL/denominator contributions.
- Removing unknown groups without repairing async credits can deadlock: trainer needs
  16 admitted prompt-groups, while the rollouter pauses around its 17-attempt allowance.
- Runner can false-pass missing/duplicated/nonfinite scores; it does not enforce the
  independent-base bound or proper verified-rejection coverage.
- All original 246 traces hit 3k recording truncation somewhere. They are diagnostics,
  not recoverable lossless actor-view ground truth.
- New bundle has 63 hard UIDs/111 cases. Hard-133 is gradient-training-disjoint but
  evaluator-development-exposed. Only 113 easy questions exist in the current bank;
  >150 independent held-out tasks cannot be manufactured through repeated mutations.
- Source hierarchy/cursor/termination parity remains open. Prep's one-row validation
  duplicates a training row. The successful smoke had save_freq=-1; no checkpoint claim.

## 6. First implementation actions (CPU only)

1. Verify the archive and reproduce the frozen-code failures using the commands below.
2. Start **R1**: explicit promotion guard + tests asserting CORRECT behavior. The current
   archive reproducers intentionally demonstrate bad behavior and are not those tests.
3. Freeze **R2** task, observation, certificate, failure and transport contracts.
4. Select a very small seed of existing easy tasks for independent source/answer/view
   certification. Build real positive/negative proof pairs, not final-string deletion labels.
5. Implement typed tool results, trusted delivered observations and terminal extraction
   (R3/R4), alongside AnswerSpec/Stage-A proof operators (R5).
6. Implement the custom outer reward manager and pure group-admission/refill state machine
   (R8); harden runner UID/schema/finite/coverage checks (R9) in parallel.
7. Only after CPU acceptance gates: candidate-image and installed adapter tests, then G1.

Do not begin by changing the judge model, adding quote/year regexes, reducing the false-
accept threshold, padding case counts, enabling a new synthesis pipeline or relaunching
`air/82_rgate_expanded.yaml` unchanged.

### Decisions to confirm before freezing the repaired protocol

The detailed plan recommends:

- Preserve the graded curve with trajectory-quality fixed to 1 initially; grade only
  validated semantic support, not tool choreography. Confirm exact rubric/coefficients.
- First repaired version keeps the actor final tag; the judge proposes a bound support
  certificate, code verifies it. An actor proof-language submission is deferred.
- Use a blinded/evidence-first support pass without gold/prose/compute stdout as evidence;
  keep the full raw trajectory archived for diagnostics. Full-model TP16 stays unchanged.
- Identify independent source reviewers and a non-synthetic source of enough additional
  real tasks for the full statistical gate. Until then, the full gate stays BLOCKED.

These are explicit proposed protocol choices, not silently deployed changes.

## 7. Reproduction commands

From repository root, no GPU/judge calls:

```bash
export PYTHONDONTWRITEBYTECODE=1
A=officeqa_pilot_records/rgate_review_2026_09_14
python3 "$A/tools/verify_archive.py"
python3 "$A/tools/replay_saved.py"
python3 "$A/tools/probe_contract.py"
python3 "$A/tools/review_latest.py"
```

Expected: all raw/report/bundle checksums and UID sets agree; frozen v2.1 replay reports
18/80 controls; defect probes show the documented forgery/parity/timeout/false-green
failures; latest-run review reports 16/80, 5/242 and 55 literal-value rejections.
New replay outputs go to fresh `/tmp` directories; inputs do not depend on the old `/tmp`.
No archive files should be rewritten while reproducing.

Existing current-source suites (they passed at review but have insufficient coverage):

```bash
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=scripts:scripts/reward \
  python3 scripts/reward/tests/test_judge_v2.py
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=scripts:scripts/reward \
  python3 scripts/reward/tests/test_reward_contract.py
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=scripts:scripts/reward:scripts/officeqa \
  python3 scripts/reward/tests/test_rgate_quarantine.py
git diff --check
```

Expected legacy counts: 12/12, 43/43, 18/18. **These are not Gate-R clearance.** Local
scientific dependencies may be absent; preserve skip counts and verify actual packages
in the candidate image. The exact-statistics dependency must not silently downgrade a
release gate to Wilson bounds.

## 8. Integration locations the next agent should inspect

Current project:

```text
scripts/reward/officeqa_grounded_reward.py  — assembly/quote checking + two mismatched entry paths
scripts/reward/grounding.py                — flat markers, output status and file-count composition
scripts/reward/strict_answer.py            — typed-unit/percent gaps
scripts/reward/judge_prompt.py             — gold/prose-exposed prompt and permissive parsing
scripts/reward/quarantine.py
scripts/_site/sitecustomize.py             — legacy sentinel/advantage patch to retire for new mode
scripts/officeqa/make_rgate_expanded.py     — invalid auto-label assumptions
scripts/officeqa/rgate_run.py               — result integrity/statistics/publishing gaps
scripts/tools/officeqa_tools.py            — typed views/cursors/provenance work
scripts/officeqa/html_table_parser.py       — header/row hierarchy work
scripts/officeqa/prep_officeqa_tool_agent.py — registry/splits and validation overlap
scripts/eval_officeqa_agentic.py            — shared finalization and actual delivered-view capture
scripts/run_grpo_fully_async.sh            — explicit protocol and resolved-config assertions
```

Pinned verl: **v0.9.0**, commit `483b8a009ba3a97563edee3a19887e4862b8094a`.
Reviewed source copies are in the archive's `upstream_snapshot/`. They are inspection
material, not the full installed package or the proposed patched runtime.

Verified extension points:

- custom agent loop via `actor_rollout_ref.rollout.agent.agent_loop_config_path`;
- `AgentLoopOutput.extra_fields` -> `tool_extra_fields` -> reward extra info/DataProto;
- custom reward manager via `reward.reward_manager.source=importlib`, module.path,
  and manager `name` as the imported class name.

Patch points requiring careful installed testing:

- `_process_single_sample_streaming`: complete group/queue publication;
- `_get_samples_from_queue`: count admitted complete groups before concat;
- `assemble_batch_from_rollout_samples`: balancing and token denominators;
- staleness/queue credits and bounded refill after rejected groups;
- outer manager failure conversion and explicit trainer completion manifests.

Do not expand the import-time `sitecustomize` hook to hide new integration behavior.
Use supported extension points plus a small exact-hash-pinned patch where necessary.

## 9. Operations and artifact identity

CLI: `~/.local/bin/air`; Databricks profile `df1`. Last exercised image is
`michaelshtelma587/verl-megatron-air:v7`. Model paths used by historical jobs:

```text
/Volumes/main/mshtelma/verl/models/GLM-5.3
/Volumes/main/mshtelma/verl/models/Qwen3.5-35B-A3B
```

The old shared outputs are at:

```text
dbfs:/Volumes/main/mshtelma/verl/eval/rgate_expanded.report.json
dbfs:/Volumes/main/mshtelma/verl/eval/rgate_expanded_scores.jsonl
```

They are overwrite-prone; use the archived run-specific copies for this review. If
fetching them later, do not assume they still belong to run 543029753940588. Verify
bundle/report/scores hashes and job/log association. New jobs must use unique outputs.
`air --watch` can drop stdout and local interruption does not cancel a cluster job;
`air logs` may stream/wait. Query Jobs API directly for terminal status.

Key SHA-256 values:

```text
317 bundle: 675561186dce6175bf6e28d5139047b8c6bb34dcf6b9897d64b85030f8694645
339 bundle: dd0e003d17df301a9aa1a2b6256478c32c35daf7817f619907ded783b8184de4
attempt 4 scores: 98aa0077f5f55cb617f691ce897694385c5d2bba2f76ecc74be6f8dc8dfe5a4c
attempt 4 report: b63f5f337f8ad67bd354962663de7e28ff2d38e5b4d0cb894d3423a0fa0673a5
original traces: 9f1e93c633fd043f0e1f607c6e5f545b16a5bdb13e2175ce885b15c09bfb858a
```

All archive hashes and checked external historical artifacts are in `manifest.json`.
The new compressed bundles reproduce the original uncompressed hashes. Do not confuse
compression hashes with run-input hashes.

## 10. Done versus not done

**Done for handoff:** latest status check; completed attempt-4 review; additive evidence
archive; portable replay/probe tools; updated broad plan/pilot README; detailed recovery
plan; this handoff; diagnostic warnings in air/82 comments. No new GPU job or git commit.

**Not done:** promotion guard, typed task/answer/ledger/certificate implementation, source
view repair, blinded judge client, independent case certification, complete-group
admission, runner hardening, candidate image, new installed-runtime parity tests, new
locked gate, grounded training or learning controls. Runtime YAML values and existing
production reward/training code were not changed by the handoff work.

**Exit condition for next agent:** leave the plan/status honest. Record what was actually
executed, preserve raw evidence, and update this handoff after each package. Do not claim
"R-gate fixed" until certified labels, actual authority/transport, all-loss group handling
and the declared statistical/coverage gates are all demonstrated.
