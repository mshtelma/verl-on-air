# OfficeQA R-gate recovery — detailed implementation plan

**Status:** implementation plan, not implemented. **Review cut-off:** 2026-09-14 10:58:22 UTC.
**Owner constraints:** real easy questions; graded reward; full GLM-5.3 TP16; preserve
pandas/numpy and bubblewrap; no unsolicited commits; preserve existing uncommitted
changes and historical artifacts.

**Decision:** NO-GO for grounded-policy optimization or larger-scale RL. GO for the
work packages below in dependency order. The old reward/checker and fixture generator
must not be promoted simply because a future run becomes green.

This document is the authoritative immediate R-gate implementation backlog. It refines
and, where necessary, supersedes the old judge-audit implementation claims and immediate
backlog in `docs/officeqa_rl_plan.md`. The broader M/S/D/R/L/T/E sequencing remains.
Read `docs/officeqa_rgate_handoff.md` first when taking over. Final review and immutable
supporting artifacts: `officeqa_pilot_records/rgate_review_2026_09_14/`.

---

## 0. Evidence this plan must explain

### 0.1 Completed GPU results

| Run | Version/bundle | Labeled controls accepted | Labeled negatives accepted | Case upper95 | Outcome |
|---|---|---:|---:|---:|---|
| 657777974855885 | bare audit / 317 | 78/80 | 121/220 | 60.668% | FAIL |
| 591895497446045 | v2 / same 317 | 63/80 | 72/220 | 38.312% | FAIL |
| **543029753940588** | **v2.1 / 339** | **16/80** | **5/242** | **4.295%** | **FAIL** |

Attempt 4 is complete, not pending. It scored all 339 records, wrote a report at
2026-09-14T05:54:57Z, and deliberately exited nonzero. Its base-ID upper is 7.414%,
unknowns are 11/339, and the wrong-answer gate is 0/17 nonzero. These metrics use
uncertified labels; they do not establish real-world judge error rates.

Of its 62 scored control rejections, **55 came from literal gold-in-quote matching**,
four from period checking, two from negative judge verdicts and one from anachronism.
Only 1/26 alternative-source controls was accepted. The CPU replay predicted this
regression direction (18/80 with saved v2 judgments); the actual live result is 16/80.

### 0.2 Mandatory regression anchors from attempt 4

| Case | What the review established | Required implementation consequence |
|---|---|---|
| UID0002_N2 | A correct 507 row survives unchanged at a later read | Mutation validation must inspect every delivered occurrence and alternative proof |
| UID0148_T | Original values `28,2444.28` are strict-list-correct but benchmark-selected as wrong; compute already produces both values | Separate numeric correctness, required formatting and support; benchmark score is not a label oracle |
| UID0204_T | Exact requested sources retain 1.47 and 1.3; Decimal subtraction gives 0.17 | Verify task-declared vintage and intermediate rounding; an original wrong answer is not necessarily a wrong evidence route |
| UID0189_R2 | Judge credits two 13-month medians from incomplete source-period coverage plus compute-authored arrays | Completeness is coverage of the proof's required inputs, not two quoted lines; historical logging loss must remain explicit |
| UID0122_T | Same-date CPI scaling cancels; euro+yen gives 0.953 pp, adding receivables gives 0.946 pp | Allow certified algebraic shortcuts; preserve category hierarchy; recompute the actual expression instead of trusting judge prose |

UID0122's precise category membership still needs original-source adjudication. Do not
promote it to a positive solely because one expression matches gold. Likewise, old
truncated traces cannot prove which additional data the original actor saw.

### 0.3 Progress retained, claims withdrawn

Retain the genuine answer-only smoke, run 616024033111491: two optimizer steps and
weight synchronization. Retain the sandbox implementation and its probes. Retain the
separate benchmark scorer snapshot and strict-answer work as a starting point.

Withdraw the claims that the 317/339 cases are independently labeled, that all residual
accepts are judge confabulation, that the new quote/year rules verify grounding, that
printed quarantine activation proves group exclusion, or that the original recorded
traces are actor-view-lossless. Existing 12/43/18-test green results did not cover the
reproduced defects.

---

## 1. Target contract and explicit design decisions

### D1. Optimize a supported answer, not unknowable internal causality

The terminal objective is:

> The assistant commits a task-correct answer that can be justified by an authentic,
> actor-visible set of observations and a valid calculation/semantic proof.

A previous mistaken calculation, an original abstention, or a misleading early lookup
does not invalidate a later supported final answer. Do not infer which hidden thought
caused the answer. Do not turn the reference proof into the only allowed traversal.

### D2. Keep binary eligibility and a graded reward

Use separate decisions:

```text
wrong/absent/malformed committed answer              -> INVALID, score 0
correct answer but verified invalid/absent support   -> INVALID, score 0
verifier/runtime failure or unresolved semantics     -> UNKNOWN, no trainable score
correct answer with valid support and derivation     -> VALID, graded score
```

Proposed initial grading, subject to owner sign-off before freezing a run:

```text
R(valid) = clip(0.30 + 0.50 * semantic_grade + 0.20, 0, 1)
```

This preserves the existing coefficients but fixes the old trajectory-quality term to
1.0, removing rewards for mandatory compute use, lack of duplicate calls, verbosity,
particular tool choreography or avoiding the turn cap. Those remain telemetry. A valid
alternative source/proof receives the same grade as an equally supported reference
source/proof. The semantic grade is finite and explicitly calibrated on development
cases; it cannot rescue invalid support. Invalid remains exactly zero.

Keep `algorithm.norm_adv_by_std_in_grpo=False`. Do not add a positive lucky floor.
Whether graded quality improves learning is a later ablation, not an assumption.

### D3. Keep the actor interface small for the first repaired version

Recommended first version: the actor still commits `<FINAL_ANSWER>...</FINAL_ANSWER>`
in its terminal assistant event. The **judge proposes a structured support certificate**
from authenticated observations and the public task requirements; deterministic code
validates its references and calculation. The judge does not rerun research tools.

This avoids requiring the actor to learn a new proof-language output while repairing
the reward. An actor-submitted certificate is a later, separately versioned extension
if it improves auditability/cost. Do not silently mix these two contracts:

- malformed **judge-proposed** certificate = verifier failure/UNKNOWN;
- malformed **actor-submitted** certificate under a future explicit actor contract =
  invalid submission, not a means to opt out of learning.

In the first version, agent prose is neither authenticated evidence nor an instruction
to the judge. Fabricated prose/stdout must never manufacture support. A separate broad
truthfulness/citation-integrity objective would require its own declared labels; do not
silently require every scratchpad sentence to be correct when evaluating support.

### D4. Use actual runtime authority, not printable markers or hashes alone

A trusted controller issues observations and commits their delivered view. The policy
cannot insert records into that ledger. IDs are episode-scoped; hashes detect corruption
but do not by themselves authenticate policy-supplied text. Authority comes from the
controller-owned data channel and source provenance.

A successful compute execution proves only that code ran. Its stdout is not a corpus
observation. Question-supplied constants may be valid inputs when the task explicitly
permits them. A sufficient search snippet is real evidence; a filename-only listing is
not. No blanket minimum read/grep/compute count belongs in the support contract.

### D5. No silent narrowing or expansion of scope

Start with manually certified **existing easy questions**, not new synthetic training
questions. Minimal artificial parser/transport/unit fixtures remain software tests and
must never count as independent real-question validation examples.

Use a declared supported-operator/task scope. Unsupported tasks fail preparation or are
reported as out of scope; they are not silently treated as correct negatives. Broader
OfficeQA claims require broader validation, including external/visual capability
limitations. Keep the local-text-only setting explicit unless a separately approved
capability expansion is implemented and re-baselined.

### D6. Prefer explicit integration over import-time monkey patches

Use the existing pinned verl extension points for a custom agent loop and custom reward
manager. Use a small, pinned, tested upstream patch only where group admission and
backpressure require it. Do not extend the `sitecustomize` advantage wrapper into an
implicit training framework. Disable the legacy sentinel patch under the new protocol;
fail startup if old and new quarantine mechanisms are both enabled.

### D7. No verifier tuning on the final gate

Historical 317/339 bundles are development/diagnostic data. Separate software contracts,
certified development cases, locked validation and natural on-policy monitoring.
Exposed hard questions stay out of training and cannot be called untouched evaluation.

**Owner decisions to confirm before implementation freeze:** D2 grade formula; D3
judge-proposed first certificate; the source of additional independent real tasks for
the full statistical gate; and who supplies the independent semantic/source reviewers.
The remaining items are repairs to already stated correctness/safety requirements.

---

## 2. Work packages, dependencies and completion states

| ID | Package | Dependencies | Current state |
|---|---|---|---|
| R0 | Archive evidence and correct status/docs | none | **DONE in this handoff** |
| R1 | Promotion guard, red regressions, issue inventory | R0 | not implemented |
| R2 | Typed task/episode/proof/outcome contracts | R1 | not implemented |
| R3 | Source hierarchy, row-preserving views and cursors | R2 | not implemented |
| R4 | Trusted ledger and shared train/eval capture | R2; R3 for certified views | not implemented |
| R5 | Typed answer and deterministic proof engine | R2; R4 for live inputs | not implemented |
| R6 | Evidence-first semantic judge and graded assembly | R2/R4/R5 | not implemented |
| R7 | Independent task/case certification and splits | R2; final certification after R3–R6 | not implemented |
| R8 | Typed reward transport and whole-group admission | R2/R4; integrate R5/R6 later | not implemented |
| R9 | Integrity-checked runner, statistics and immutable publishing | R2/R7; can begin runner hardening after R1 | not implemented |
| R10 | Installed-image and GPU validation ladder | relevant CPU gates from R1–R9 | not started |
| R11 | Controlled learning, regression monitoring and handoff maintenance | R10 and required R clearance | blocked |

Parallel work after R2: source/view work; pure answer/proof engine; runner integrity;
and reviewer task annotation. Do not finalize labels before the delivered-view contract
is frozen. Do not start live judged optimization merely because one branch is ready.

---

## 3. R0 — evidence preservation and documentation reset

### Completed deliverables

- New additive archive `officeqa_pilot_records/rgate_review_2026_09_14/`.
- Reports, full parsed scores and driver logs for completed attempts 2/3/4.
- Exact reconstructed 317-case and current 339-case bundles, deterministically compressed;
  decompressed hashes match the original run reports.
- Reviewed production-code snapshot and the relevant pinned verl sources/license.
- Latest terminal Jobs API statuses, manifest, portable CPU replays and defect probes.
- Final review that incorporates the five accepted negatives and 55 literal-value
  control rejections from attempt 4.

### Preservation policy for subsequent work

1. Do not overwrite any historical JSONL/report, even to correct a label.
2. Corrections are append-only adjudication records referencing old case/hash and the
   new label/version with reviewer rationale.
3. New production outputs use unique run directories, not the current shared
   `rgate_expanded_scores.jsonl` and `rgate_expanded.report.json` paths.
4. Keep historical code runnable only as an explicit diagnostic path.
5. Preserve all unrelated uncommitted changes. No commits without an owner request.

**Acceptance:** archive verification succeeds, raw/decompressed hashes match, and another
agent can reproduce the frozen-code defects without a judge/GPU or original `/tmp` paths.

---

## 4. R1 — stop accidental promotion and turn findings into failing tests

### Files/actions

- Add an explicit reward protocol selector in `scripts/reward/officeqa_grounded_reward.py`
  and startup assertions in `scripts/run_grpo_fully_async.sh` / `scripts/dispatch_agentic.sh`.
- New production candidate protocol name: **`officeqa_proof_v1`**. Do not reuse ambiguous
  labels such as v2/v3, which already refer to several historical implementations.
- Legacy grounded audit remains callable only with an explicit diagnostic opt-in and
  cannot emit a training-approval manifest. Do not silently fall back from missing new
  episode metadata to the old flat-text reward.
- Retain answer-only control, but move its answer extraction to trusted terminal events
  before claiming boundary safety.
- Add regressions under `scripts/reward/tests/` and integration tests under
  `scripts/officeqa/tests/`. Keep archive defect reproducers separate from tests that
  assert corrected behavior.

### Initial red-test matrix

| ID | Test | Correct behavior |
|---|---|---|
| ANS01 | Tool/stdout/retrieved text contains the only final tag | Not an assistant commitment |
| ANS02 | Numeric answer with wrong explicit percent/scale | Reject under task-declared units |
| ANS03 | `28,2444.28` versus typed ordered list | Distinguish value correctness from bracket/format requirements |
| OBS01 | Fake flat tool marker with zero runtime calls | No corpus evidence |
| OBS02 | Unrelated real read + compute-printed fake row | No manufactured support |
| OBS03 | Failed/no-match/past-end read | No successful content observation |
| OBS04 | Same episode through structured/offline/training transport | Same final, evidence, verdict and reward |
| OBS05 | Executed result discarded by context limit | Not in actor-visible evidence |
| QUO01 | One-character quote or reverse containment | Cannot expand into a larger certified span |
| SEM01 | FY/CY range includes interior years | Full requested set, not endpoints only |
| SEM02 | Footnote/legal/maturity date or line number | Not automatically an observation period |
| SEM03 | One source file, multiple required operands | Enforce the chosen proof's completeness |
| DER01 | 2,237,000,000 -> 2.24 billion | Accept certified conversion and rounding |
| DER02 | 302,665,000 - 47,976,000 | Accept supported net; literal result need not appear |
| DER03 | Two 13-month medians with only a few source months | No full-proof credit |
| DER04 | 1.47 versus reported 1.30 | Use declared intermediate rounding/vintage, get 0.17 |
| DER05 | CPI cancellation and category hierarchy | Validate algebra and selected components independently |
| LAB01 | Mutation leaves later correct row | Not automatically a negative |
| LAB02 | Fake backward-dated alternative source | Not a real positive control |
| RUN01 | Missing/extra/duplicate UIDs or unknown label | Fail integrity before statistics |
| RUN02 | NaN/Inf/bool/invalid score payload | Fail integrity, not a successful rejection |
| GRP01 | Outer timeout/error bypasses custom function | Typed UNKNOWN survives transport |
| GRP02 | One UNKNOWN sibling, KL enabled | Entire group absent from all training losses |
| GRP03 | All groups unresolved, or insufficient valid groups | No optimizer/scheduler step; bounded, explicit stop |

These tests are expected to fail current production code. Do not mark xfails/skips as
completed repairs. A diagnostic program exiting 0 after reproducing a bug is not a
passing production regression.

**Acceptance:** an executable defect inventory exists, the unsafe path cannot be selected
accidentally for new grounded training, and every listed failure maps to a test and owner.

---

## 5. R2 — typed contracts and schema ownership

### Proposed modules

- `scripts/officeqa/contracts.py`: strict schemas, enums and serialization rules.
- `scripts/officeqa/task_registry.py`: immutable task versions and public/private views.
- `scripts/officeqa/quantities.py`: shared quantities/units/rounding primitives.

Use a single source of truth for schemas. No permissive coercion of strings into
booleans, booleans into scores, unknown fields into defaults, or nonfinite numbers.
Financial values are decimal strings/rationals, not binary floating-point JSON values.
Use fixed schema keys, including null optional fields, so verl's reward-extra-info
aggregation cannot depend on the first sample's accidental key set.

### 5.1 TaskSpec

Separate public semantic requirements from private oracle data:

```json
{
  "schema_version": "officeqa.task.v1",
  "task_id": "UID0043",
  "task_version": "content-hash",
  "question_hash": "content-hash",
  "answer_spec": {
    "kind": "quantity",
    "unit": "USD",
    "display_scale": "1",
    "decimal_places": 0,
    "rounding": "explicitly-adjudicated-rule",
    "allow_equivalent_explicit_units": false
  },
  "requirements": [
    {"id": "gross", "concept": "liquid-fuel gross receipts", "period": "FY2004"},
    {"id": "refund", "concept": "corresponding liquid-fuel refunds", "period": "FY2004"}
  ],
  "allowed_proof_plans": ["gross_minus_refund", "equivalent_published_net"],
  "supported_operator_version": "arithmetic.v1",
  "scope": "certified_easy_development"
}
```

The real schema must additionally support:

- entity/series/category and allowed semantic aliases;
- exact unit/scale, nominal/real basis and percent versus percentage points;
- period kind: FY, CY, month, as-of, interval, issue/maturity date, forecast target;
- required measurement dates and the applicable fiscal-calendar definition;
- requested reporting vintage and actual/estimate/forecast qualifiers;
- exclusions, footnotes, statistical convention and intermediate rounding;
- scalar, ordered vector, named tuple, text enum, and calendar date answers;
- legitimate question-supplied constants and algebraic assumptions;
- fact/series/alias cluster IDs for splitting and uncertainty accounting.

A fiscal year is not universally a calendar year or a modern October–September year.
Publication date is distinct from measurement period and instrument maturity. Ranges
must be expanded according to the spec, not extracted by a generic year regex.

Private oracle data includes gold value, independently verified reference proofs,
source-page evidence, reviewer records and answer-key revision. It is available only
to the verifier/evaluation side. The actor and semantic judge do not receive private
gold values or reference-file hints unless the question itself specifies that source.

### 5.2 Episode and observation contracts

`EpisodeEnvelope`:

```text
episode_id, rollout_group_id, sibling_index, task_id/version
actor/model/tokenizer/controller/corpus/tool versions
ordered trusted assistant/tool events
terminal_assistant_commitment
complete delivered-observation ledger and hash
termination reason and actual per-layer budgets
policy-version start/end, sampled-token mask and serialization hashes
```

`Observation`:

```text
observation_id, episode_id, tool_call_id, sequence number
kind = corpus | search_snippet | listing | computation | error
status = ok | no_match | not_found | invalid_request | timeout | tool_error
source document/hash and original span/table references when applicable
raw result reference/hash; exact delivered body/hash
visible rows/cells/context references; dropped/truncated regions
whether delivery was actually committed to the model context
next cursor/table completion metadata
```

Metadata is controller-created; source text must never be parsed as an observation
envelope. A policy-provided ID is merely a lookup request until resolved in that exact
episode's trusted ledger. Cross-episode reuse, stale IDs and undelivered results fail.

### 5.3 Support certificate

The judge selects references, not numerical facts invented in JSON:

```json
{
  "schema_version": "officeqa.support.v1",
  "decision": "supported",
  "proof_plan": "gross_minus_refund",
  "bindings": [
    {"slot": "gross", "observation_id": "o1", "cell_id": "r17c3", "context_refs": ["h3", "u1"]},
    {"slot": "refund", "observation_id": "o1", "cell_id": "r31c3", "context_refs": ["h3", "u1"]}
  ],
  "semantic_checks": {"category": true, "period": true, "unit": true, "vintage": true},
  "unmet_requirements": [],
  "semantic_grade": 1.0,
  "reason_codes": []
}
```

The verifier resolves values from references, validates required visible headers and
footnotes, executes the plan, and checks final-answer agreement. No number from the
judge is trusted merely because it appears in the certificate. Large vector bindings
may reference a bounded column/row set, but coverage and filtering must be checkable.

### 5.4 VerificationOutcome and failure taxonomy

Keep independent fields: answer correctness, support validity, numerical proof result,
judge-call state, error origin, reward eligibility and final reward.

| Situation | Outcome | Trainable? |
|---|---|---|
| Missing/malformed/wrong terminal answer | INVALID, 0 | yes, ordinary negative |
| Complete audit establishes wrong row/unit/period or missing required source support | INVALID, 0 | yes |
| Malformed/contradictory judge output or bad judge-generated references | UNKNOWN | no |
| Missing/corrupt runtime ledger, judge service outage, outer reward timeout | UNKNOWN or fatal environment error | no |
| Dataset contains unsupported/uncertified TaskSpec | preparation/configuration failure | no job |
| Valid proof and correct final answer | VALID, graded | yes |

Distinguish `UNSUPPORTED` evidence from `UNSCORABLE` historical logging loss. Distinguish
a policy's invalid tool request from global corpus/staging failure. A routine no-match
call is not itself fatal if other observations support the final answer.

`UNKNOWN` may carry a finite transport placeholder because verl requires a scalar, but
must have `train_eligible=false`; batch admission is forbidden from interpreting the
placeholder as a reward. Remove sentinel equality as the source of truth.

**Acceptance:** schema round-trips are strict and deterministic; private/public task
views are tested; inconsistent combinations are rejected before scoring; every error
origin has a defined disposition and reason code.

---

## 6. R3 — repair source hierarchy and observable tool views

### Files

Modify `scripts/officeqa/html_table_parser.py`, `chunker.py`, `build_chunks.py`,
`scripts/tools/officeqa_tools.py`; add `scripts/officeqa/table_ir.py` and
`observation_formatter.py`. Preserve legacy rendered corpora and indices by version.

### 6.1 Structured table representation

1. Parse cells with original text, origin coordinates, rowspan/colspan, header role,
   superscripts/footnotes and source offsets.
2. Expand the ownership grid without discarding which parent header owns each child.
3. Build full column and row header paths. A body `<th>` must not make all prior rows
   column headers. Nested/malformed tables need explicit diagnostics.
4. Preserve raw text separately from normalization/OCR suggestions. Never silently
   change financial numbers or infer missing signs/zeroes.
5. Retain caption, unit, period, source/vintage and footnote references with stable IDs.
6. Render Markdown from this IR for the actor; maintain a mapping from delivered text
   back to source cells. Escaped pipes are data, not column delimiters.
7. Validate original page images for the starter bank and ambiguous hierarchy cases,
   including the euro/yen/receivable grouping in UID0122.

Do not claim the entire corpus is certified because the parser passes toy tests. Audit
a stratified set and scope training to verified task/source views until expanded.

### 6.2 One delivered-view budget

- Build typed tool results first, then render one bounded actor-visible payload.
- Fit complete rows/paragraph spans together with their necessary context; avoid
  arbitrary character cuts inside numbers, rows, multibyte text or headers.
- If one row is too large, return an explicit bounded-view failure/continuation path,
  not a silently chopped cell that looks complete.
- `next_start_line`/cursor means the next **undelivered** source content, not requested
  start + requested count. Distinguish requested, available and delivered ranges.
- Keep units/header context on continuations. Context repeated in a new observation
  has source identity; do not count repeated cells as distinct operands.
- Search snippets are source spans with provenance. Listing-only results are typed
  as listings. Neither the score nor filename metadata contributes numerical cells.
- Keep the existing public string tools where necessary, but have a common typed
  internal implementation; the controller receives typed metadata out of band.

The model must receive the same evidence the verifier uses. If the training framework
adds a second truncation, either configure it not to truncate or capture its exact final
output and mark the omitted regions. Validate the actual deployed behavior.

### 6.3 Tests and acceptance

Test multi-row/colspan headers, row headers, footnote superscripts, negative/accounting
numbers, escaped pipes, truncated HTML, repeated headers, oversized rows and exact cursor
continuation. Golden-page fixtures need expected semantic header paths, not just equal
numeric strings. Require no lost/duplicated cells when traversing successive pages.

**Acceptance:** the starter bank's necessary evidence is obtainable through the actual
actor interface; every certified binding has visible required context; corpus/view
changes receive new hashes and require a new paired baseline.

---

## 7. R4 — trusted ledger and identical training/offline capture

### Files/integration points

- New `scripts/officeqa/ledger.py`, `episode_replay.py`, `verl_agent_loop.py`.
- New `scripts/officeqa/agent_loop.yaml` with the custom loop target.
- Modify `scripts/eval_officeqa_agentic.py` to use the same event/view finalization.
- Modify prep/launch configuration to select `agent_name=officeqa_tool_agent`.

Pinned verl v0.9.0 already provides two useful channels:

- `rollout.agent.agent_loop_config_path` loads custom loop targets;
- `AgentLoopOutput.extra_fields` is passed through `tool_extra_fields` to the reward
  manager, and reward diagnostics are carried into `DataProto.non_tensor_batch`.

Use these channels explicitly. They avoid pretending the flattened decoded response
is an authenticated transcript. Validate them against the installed image; a source
inspection or fake-registry test is not sufficient.

### 7.1 Capture ordering

1. Create episode/group/sibling identity in the controller.
2. Capture parsed assistant actions from trusted generation events; preserve their
   token IDs and generated-token masks.
3. Execute a tool through the shared typed implementation.
4. Store raw result/status privately; create the bounded delivered view.
5. Apply any actual framework truncation/template handling.
6. Commit an observation as delivered only when those tokens are appended to model
   context. An executed call whose output is dropped at the episode cap is not evidence.
7. Record the final assistant event and termination cause.
8. Freeze the envelope and transport its data/hash via trusted extra fields.
9. Persist the same envelope for offline replay, with immutable blobs if necessary.

Prefer bounded inline metadata/data for the first pilot over worker-local path strings
that other nodes cannot resolve. If blobs are externalized, use a shared immutable
content store and verify the content hash; do not trust arbitrary policy-supplied paths.

### 7.2 Terminal answer extraction

- Extract only from the trusted terminal assistant event and declared final channel.
- Reject absent/multiple/malformed commitments according to AnswerSpec.
- Do not accept tags in tool results, compute stdout, retrieved text or draft reasoning.
- Do not use `rec.pred` as authoritative in the production scorer; it is a derived
  diagnostic checked against the real commitment.
- Remove the production fallback that treats a marker-free string as entirely assistant
  text. Missing trusted metadata is a protocol error, not permission to guess roles.

### 7.3 Parity and trust tests

Replay one frozen episode through the offline adapter and the installed reward-manager
transport. With a cached semantic verdict, require exact equality of:

```text
terminal commitment / typed answer
trusted observation IDs and delivered bytes
resolved values + header/unit/period references
support/unknown/error status
reward and train eligibility
actor-token versus observation-token masks
```

Include read-only, sufficient-snippet-only, failed read + valid later read, parallel
calls, Unicode, role-marker strings inside documents, late context exhaustion, duplicate
observations, forged IDs, cross-episode references and policy-version transitions.
Run concurrency tests so one episode's output can never be credited to another.

**Acceptance:** the structured/flat mismatch and all authority-forgery probes are fixed
through the actual adapter, not just `_assemble` with hand-built dictionaries.

---

## 8. R5 — typed answer parsing and deterministic derivation verification

### Files

Refactor `scripts/reward/strict_answer.py`; add `evidence_bindings.py`, `derivation.py`
and `officeqa_verifier.py`. `officeqa_grounded_reward.py` becomes a thin adapter to the
shared verifier. Keep `officeqa_reward_upstream_pinned.py` unchanged for reporting.

### 8.1 Answer parsing

- Require AnswerSpec for the production typed gate; no guessing unit semantics from
  whether the gold string happens to contain a word.
- Separate syntax, arity/order, unit/scale, numeric value and requested format results.
- Support leading decimals, grouped thousands, scientific notation, signs, explicit
  accounting notation, exact ordered lists/mixed enums and canonical dates.
- Parentheses mean what the declared type says; do not treat accounting negatives as
  arbitrary scalar wrappers. A list delimiter is not a thousands separator.
- Normalize explicit units to quantities, then enforce the declared display policy.
  `0.5%` is not the same dimensionless value as `0.5`.
- Permit equivalent formatting only when declared. Do not broadly erase text, units,
  parentheticals, signs or list structure to force equality.
- Use Decimal/rational arithmetic and task-defined rounding. Compare values at the
  required precision; do not introduce a generic fuzzy tolerance to rescue failures.
- Retain benchmark exact/1%/5% metrics separately and record backend/hash. Do not change
  historical benchmark numbers or use benchmark correctness to label support.

### 8.2 Evidence resolution

Each binding must resolve to an in-scope, delivered, successful source/question span
whose identity and exact value can be checked. Reject cross-episode/missing references.
A substring of a longer quoted string does not authenticate the rest of that string.
No reverse containment, first-match-anywhere association or whole-line expansion from
one character is allowed. Numeric extraction excludes file IDs, line numbers, search
scores and footnotes unless the task genuinely asks for those values.

Use context references to verify the selected cell's semantic interpretation. Missing
required header/unit/qualifier context cannot be supplied from an unseen part of the
corpus. A verifier may inspect full sources for integrity/auditing, but may only credit
what was actually delivered to the actor.

### 8.3 Bounded operator engine

Implement an allowlisted interpreter over typed bindings and question-derived constants.
No `eval`, arbitrary Python, network/file access, or execution of the agent's compute
program in the verifier. Bound node count, depth, vector size, numeric precision,
exponent sizes and execution time. An arbitrary literal equal to the gold is not a
valid proof leaf.

| Stage | Operators | Required semantic/completeness checks |
|---|---|---|
| A: initial | identity, sum, subtraction, absolute difference, ratio, unit conversion, rounding | correct slots, compatible units, denominator constraints, declared intermediate rounding |
| B | arithmetic/weighted mean, percent/percentage-point/arc change, count/filter | full selected domain, weights, period sets, strict `>` vs `>=`, valid exclusions |
| C | median, geometric mean, log, population/sample variance and stddev | complete vectors or a separately registered valid certificate, domain positivity, ddof, missing values |
| D | OLS slope/intercept/prediction, Pearson correlation, KL divergence | exact input pairing/order, time origin, normalization, degeneracy and precision contracts |
| E: only after annotation | Hill/Pareto, Zipf fitting, VaR and other specialized tasks | explicitly agreed formulas, thresholds, supplied constants, exclusions and independent reference calculations |

Do not call R-gate general merely because Stage A passes. Task preparation must reject
unsupported operators before training. Extend the task and validation scopes together.

### 8.4 Coverage is a proof property

- One bulletin can contain many required operands; number of files is irrelevant.
- Multiple reference files can be replaced by one valid published aggregate.
- Count unique required logical inputs, not unique quote strings or observations.
- For a period vector, compare the selected period set with the task's required set.
- For an enumeration/filter, establish the domain was covered and no eligible rows
  were silently omitted; a few example rows do not certify a count/geometric mean.
- For UID0189, two quoted rows cannot certify two 13-month medians. A future alternate
  order-statistic certificate must prove enough bounds explicitly, not waive coverage.
- For UID0122, implement common positive scaling cancellation only as a typed algebraic
  identity with the same factor applied to numerator and denominator for each date.
  Independently validate category membership; cancellation does not justify including
  accounts receivable in the wrong category.

### 8.5 Numerical testing

Use exact rational/Decimal expected values for arithmetic, independent implementations
and high-precision fixtures for statistical operators, and explicit numerical error
bounds before final task rounding. Test zero/negative denominators, cancellation,
near-rounding boundaries, extremely large inputs, repeated values and NaN/Inf.

**Acceptance:** registered plans reproduce independently certified answers; wrong
bindings/formulas/units cannot earn positive reward; legitimate transformations and
alternative proofs are not rejected because the final string is absent from a source.

---

## 9. R6 — evidence-first judge, strict client and graded assembly

### Files

Refactor `scripts/reward/judge_prompt.py`; add `semantic_judge.py`; simplify the client
and assembly in `officeqa_grounded_reward.py`. Preserve old prompt/code snapshots for
historical replay, not silent fallback. Modify `scripts/serve_judge.sh` only after CPU
and mocked-server tests establish the new request/reporting contract.

### 9.1 Judge input/output

Retain the full GLM-5.3 TP16 model. The first support pass gets:

- the question and public TaskSpec;
- the complete delivered corpus/search observation set, or a declared complete proof
  view with visible coverage accounting;
- allowed proof-plan schema and opaque observation/cell/context IDs.

It does not get the gold final value, match status, expected case label, case-family
suffix, reference proof/file whitelist, persuasive agent prose or compute stdout as
source evidence. Preserve the complete raw trajectory in artifacts; optional full-trace
analysis is diagnostic and cannot override eligibility. This input change is an explicit
protocol revision, not a hidden truncation of the old audit.

The judge returns the strict support-certificate schema. Category, period, units,
vintage and chosen-plan completeness must be consistent with the overall decision.
`targeted_right_category=false` or missing mandatory checks cannot coexist with a
positive eligibility. A numeric confidence cannot overrule a false semantic flag.

### 9.2 Parsing and retries

- Parse exactly the terminal final JSON response, not a convenient scratchpad object
  found in reasoning text. Save raw content and reasoning separately.
- No invented verdict/route defaults, no string-boolean coercion, no silent clipping
  of out-of-range scores, and no truncating quoted evidence to 500 characters.
- Invalid/missing fields or references in a judge-authored certificate are UNKNOWN,
  not an ordinary negative attributed to the actor.
- Retry bounded transient transport failures on the same immutable episode. Log every
  attempt. Never retry until a positive is obtained or keep the maximum score.
- If adding a schema-repair call, predeclare one fixed repair policy, no gold feedback,
  hash the repair prompt and count it in cost/reproducibility. Otherwise return UNKNOWN.
- Malformed task/configuration/runtime invariants should fail the job rather than
  quietly become many ordinary negative rewards.

### 9.3 Token budgets and deadlines

Compute actual input token count with the pinned judge tokenizer/template, including
system text, schema and all evidence. Require:

```text
input_tokens + reserved_generation_tokens + declared_margin <= context_window
```

Do not substitute a character ceiling for this condition. Do not silently head/tail
truncate. Validate that allowed actor/tool/parallel-call budgets fit the judge contract;
if not, lower the shared episode scope or use an explicitly validated proof-view protocol.
An honest in-contract episode exceeding verifier capacity is UNKNOWN/configuration
failure, not unsupported evidence.

Carry one overall deadline through queueing, HTTP calls, retries and outer reward
transport. The outer manager must not terminate a legitimate inner retry budget and
convert it to zero. Record queue time, input/output tokens, finish reason, latency,
HTTP failures and deadline origin. Stress both over-budget and just-under-budget cases.

### 9.4 Reproducibility and grading

Pin model weight manifest, tokenizer/template, image digest, judge prompt/schema,
reasoning effort, temperature, seed where supported, completion budget and concurrency.
Temperature zero is not proof of repeatability; measure it on repeated cases.

Cache support judgments by exact public-task/evidence/prompt/model/config versions.
Cache final rewards separately with oracle, answer-normalizer, proof-engine and reward
policy versions. A gold correction must invalidate final rewards even if the support
view is unchanged. Never share cache entries across incompatible protocols.

Calibrate grade on development data after eligibility is validated. Test equivalent
source/proof score parity and invariance to irrelevant prose/padding. Keep efficiency
terms out of the first repaired reward. Record graded-score variance within all-valid
and mixed-validity groups; do not manufacture useful signal from judge noise.

**Acceptance:** mocked failures and strict parsing pass; reference/prose leakage tests
pass; output references are checkable; exact budget handling and natural unknown rates
are measured; the live sanity suite validates the same contract.

---

## 10. R7 — independently certify tasks, cases and splits

### Files/artifacts

- New `scripts/officeqa/certify_cases.py`, `audit_task_splits.py`.
- Replace the generator's label assignment logic in `make_rgate_expanded.py` with a
  versioned case-builder interface; keep legacy generation available only diagnostically.
- New versioned task/spec, reference-proof, label and split manifests under
  `officeqa_pilot_records/rgate_certified/<version>/` or a corresponding immutable Volume.
- Modify `prep_officeqa_tool_agent.py` to consume the registry/split manifest, not select
  arbitrary rows and infer composition from source-file count.

### 10.1 Starter bank

Select approximately 20–30 existing easy questions spanning the initial operators,
unit/rounding cases, sufficient snippets, one-file multi-operand calculations and genuine
alternative sources. Keep the natural questions unchanged. Selection must be declared
before evaluating the candidate, not based on which cases it happens to pass.

For each task:

1. Two reviewers independently inspect original source pages and the delivered view.
2. Derive/verify the numerical answer independently of the training judge's verdict.
3. Adjudicate task interpretation, row/column hierarchy, units, vintage and rounding.
4. Record a valid reference proof and at least one alternate proof when genuinely
   available; lack of an alternate does not justify fabricating one.
5. Mark missing source visibility, ambiguous gold and unsupported operators explicitly.
6. Seal the task/spec/oracle/version and reviewer evidence before using it for learning.

Reviewers should be blinded to candidate judge outputs/scores and mutation labels during
initial assessment. Agreement by two models reading the same corrupted table is not
independent source validation.

### 10.2 Label schema

Store, independently of judge input:

```text
case_id, task_version, episode/ledger hash, mutation spec and parent case
expected answer correctness / formatting / support / citation-integrity separately
expected outcome and permitted reason codes
proof or anti-proof explanation with source-visible references
reviewer decisions, disagreement/adjudication and certification status
fact/alias cluster, hazard family, development/locked/exploratory split
```

A case cannot enter release statistics with a pending/ambiguous/unscorable label. Do not
remove a failing case after judging without preserving the old result and documenting
why the label or scope changed. Certification changes create a new bundle/version.

### 10.3 Rebuild each hazard family

| Family | New construction rule |
|---|---|
| Grounded positive | Independently certified visible proof, not merely benchmark-correct answer |
| Alternative source | Actual alternative document and observed equivalent data; explicit vintage constraints |
| Unsupported | Remove/withhold every valid supporting route in the delivered evidence, including sufficient snippets and alternate representations; re-audit |
| Fabricated evidence | Same unsupported condition plus policy-authored fake prose/stdout/IDs; test provenance, not a misleading deletion label |
| Wrong row/column/period | Select genuine wrong bindings/evidence, or a clearly labeled test-corpus variant; inspect all later reads and aliases |
| Missing component | Omit a necessary input/context element of all remaining valid plans, not every string lacking the final answer |
| Transplant | Audit the resulting commitment against remaining evidence; original wrong/abstain/format status does not determine support |
| Corrupt metadata/source | Separate integrity/environment test; do not pass off impossible runtime observations as ordinary valid sources |
| Style/injection | Semantically equivalent observation set plus untrusted injected instructions/prose; expected invariant support/score |
| Wrong final | Typed wrong answer with valid evidence; exactly zero reward and separate answer-error reason |
| Legitimate shortcut | Published aggregate, equivalent source, corrected final calculation or certified algebraic cancellation |

Mutation postconditions are necessary but not sufficient. Automated proof search over
known allowed plans plus independent review must verify that a negative did not leave a
valid alternate route. Do not promise a formal proof over every imaginable derivation.

### 10.4 Splits and data preparation

- Declare train, development, locked validation, natural monitoring and historical
  diagnostic exposures by UID AND fact/series/alias cluster.
- Keep hard/Pro and exposed hard traces out of gradient training; disclose their
  previous evaluator-development exposure.
- Fix the prep bug where the last training row is also the validation row. A one-row
  validation dataset must use a genuinely different declared validation UID, or be
  labeled a non-evaluative loader fixture rather than held out.
- Write parquet under immutable dataset-hash paths; assert actual retained row counts,
  task specs, token budgets and split disjointness after tokenizer-side filtering.
- Do not include private oracle values/source hints in actor-visible prompts or tools.
  Keep framework-required ground truth in its private reward channel and verify hashes.

### 10.5 Data sufficiency is a real blocker

The 113 easy questions cannot by themselves provide 150 independent held-out questions
while also supporting development/training. Do not replace independence with repeated
mutations. Obtain additional independently authored real-corpus tasks from the owner or
an approved source before claiming the full statistical gate. No automatic synthetic
question generation is assumed by this plan.

Until then, report a **certified finite-bank/development result**, not full Gate-R
clearance or novel-question generalization. Keep the full-scale permission blocked.

**Acceptance:** every release case has an independently supported label and scope;
mutation audit, source visibility and split checks pass; the data-sufficiency shortfall
is explicit rather than hidden in case counts.

---

## 11. R8 — typed transport and real whole-group quarantine

### Files and pinned integration points

- New `scripts/reward/officeqa_reward_manager.py`.
- Replace the production sentinel logic in `scripts/reward/quarantine.py` with a pure
  group-admission state machine; retain old code only for archived replays.
- New `scripts/officeqa/group_admission.py` or equivalent single shared module.
- Small pinned verl patch for producer/collector admission/backpressure and completion
  assertions, stored as a reviewed patch under `docker/patches/` if no supported hook
  covers these semantics. Add exact base-commit/file-hash checks; no fuzzy patch apply.

The inspected reward loader supports:

```text
reward.reward_manager.source = importlib
reward.reward_manager.module.path = <officeqa_reward_manager.py>
reward.reward_manager.name = OfficeQATypedRewardManager
```

Validate this exact configuration in the candidate image. The custom manager must own
outer timeout/error conversion; simply overriding the custom score function leaves the
current RateLimitedRewardManager's ordinary-zero fallback in place.

### 11.1 Outcome transport

Every sample returns the same diagnostics schema, including protocol/version, episode
hash, terminal resolution status, train eligibility, failure origin, attempts and reward.
Typed UNKNOWN must survive `AgentLoopOutput`, `tool_extra_fields`, reward-loop response,
`reward_extra_info`, `DataProto`, cloudpickle and queue delivery. Missing fields in an
OfficeQA proof-protocol run are fatal contract violations, not default success/zero.

Retain RPM/concurrency/deadline controls, but test failures in the wrapper itself,
serialization and worker process—not just failures caught inside `compute_score`.

### 11.2 Group state machine

```text
GENERATING -> VERIFYING -> RESOLVED_VALID_FOR_TRAINING -> ADMITTED
                      -> RETRY_PENDING -> VERIFYING
                      -> QUARANTINED
protocol corruption / incompatible versions -> FATAL
```

A group consists of the configured number of siblings under one rollout-group ID,
not all generations of the same benchmark UID. Check unique sibling indices, expected
cardinality, task/version, verifier version, episode identities and permitted policy
staleness. An ordinary INVALID/zero-reward member does not quarantine the group.

Retry only verification of the original immutable rollout. Never regenerate just the
unknown sibling, substitute a new outcome or recompute old rewards under a changed
verifier. Once unresolved after the bounded policy, quarantine the entire group.

### 11.3 Admission before losses, not advantage masking

The preferred implementation physically excludes unresolved groups **before** concat,
balancing, old/ref log-prob computation, token-denominator calculation and advantage
formation. Then no policy, KL, entropy, auxiliary, optimizer-normalization or scheduler
contribution can survive from quarantined rows.

Keep defensive eligibility assertions immediately before advantage computation and
actor update. If all groups are quarantined, perform no optimizer or scheduler step;
Adam state/weight decay/global step must remain unchanged. Do not call a zero-advantage
optimizer step equivalent to dropping data.

### 11.4 Fully-async batching and backpressure

The current smoke requires **16 prompt-groups per sync**, each with four responses.
Filtering must collect 16 **admitted** groups, not receive 16 groups and then remove
some while retaining the old denominator.

Inspected upstream points:

- `fully_async_rollouter._process_single_sample_streaming`: complete group available
  before publishing; currently increments generation counters after queue insertion.
- `fully_async_trainer._get_samples_from_queue`: currently counts serialized blobs
  before decoding/validating them, then concatenates/balances.
- `detach_utils.assemble_batch_from_rollout_samples`: concatenation and token totals.
- rollouter `staleness_samples` / `max_required_samples` pause generation until sync.

Add explicit counters and idempotent credit release for rejected/quarantined groups.
Otherwise generation can pause after 17 attempts while the trainer waits forever for
16 usable groups. Track attempts, in-flight verification, published/admitted/quarantined
and consumed groups separately. Protect counter updates with the existing concurrency
lock and deduplicate release/ack events by group ID.

Bound refill by maximum attempts, wall time and unknown-rate circuit breakers. Dataset
exhaustion with too few admitted groups is `INSUFFICIENT_RESOLVED_GROUPS`, not successful
completion. Total generated attempts and requested optimizer steps must be separate
configuration/report quantities. Do not promise exactly two steps from 32 attempts if
some groups may be quarantined.

### 11.5 Tests

- Actual pinned manager timeout/error methods with lightweight doubles, then installed
  Ray/DataProto integration; one missing diagnostic key must fail loudly.
- One/all/multiple unknown siblings; late response, duplicate queue event, replayed ID,
  partial group, version mismatch, retries and group timeout.
- Genuine zero rewards mixed with positives remain trainable and retain the correct
  group mean with std-normalization OFF.
- Compare losses/gradients to a physically filtered reference batch with KL and entropy
  enabled. Compare effective denominators, not just advantages.
- All-unknown path leaves parameters, optimizer state, scheduler and step counters
  unchanged; tests must include nonzero weight decay/momentum where applicable.
- Simulate refill with the 16-group/17-credit pause boundary and prove no deadlock.
- DP divisibility and balancing use only complete admitted groups; avoid fake training
  rows to fill a batch. Bound partial-last-batch behavior explicitly.

**Acceptance:** unknowns cannot become ordinary negatives or touch any training loss,
and quarantine cannot silently shrink, stall or falsely complete optimizer batches.

---

## 12. R9 — trustworthy gate runner, uncertainty and artifact publishing

### Files

Refactor `scripts/officeqa/rgate_run.py`; add `rgate_stats.py`, `rgate_artifacts.py`,
`compare_rgate_runs.py`. Use independent tests, not the same helper as both implementation
and expected-value oracle.

### 12.1 Preflight and result integrity

Before contacting a judge:

1. Validate schema/protocol, bundle hash, exact case UID uniqueness, label certification
   and immutable task/episode references.
2. Check split/exposure policy, declared supported scope and required family coverage.
3. Validate source/corpus/tool/template/model identities and callable entry points.
4. Assert all configuration and thresholds match the sealed protocol.
5. Create a new run directory exclusively; refuse existing finalized output paths.

Before statistics/promotion:

- exact equality of expected and observed UID sets;
- exactly one terminal resolution per expected case, with retries stored separately;
- no duplicate/missing/extra cases, unknown labels or contradictory outcome fields;
- finite numeric rewards/grades, no bool-as-number, strings, NaN/Inf or silent defaults;
- complete metadata, consistent versions and exact expected record counts;
- nonempty required positive/negative/wrong-answer families and adequate cluster counts;
- an UNKNOWN carrying a trainable positive or eligible=true is an integrity failure.

### 12.2 Statistical contract

Preserve the original intent:

- valid-proof acceptance >=95%, with unknowns included as non-accepts;
- verified rejection of invalid-but-answer-correct proofs >=98%; UNKNOWN is not a
  demonstrated rejection;
- one-sided exact 95% false-positive authorization upper <=2%;
- wrong-answer gate exactly zero;
- bounded verifier UNKNOWN rate among eligible/requested judgments, separately from
  all rollouts and skipped wrong answers;
- all deterministic authority/answer/transport canaries pass.

Use a predeclared independent unit (conservative question/fact/alias cluster). A cluster
fails if any evaluated negative variant gets positive trainable reward. Report case
metrics too, but do not enforce only the case bound and merely print the cluster bound.
Report cluster coverage/unknowns so abstention cannot masquerade as successful rejection.

Use exact Clopper-Pearson, including explicit x=0, x=n and n=0 handling. No silent
Wilson fallback for release decisions. If the exact-statistics dependency is unavailable,
fail preflight or use an independently tested exact implementation. JSON reports may
not contain NaN. With zero errors, 0/150 gives an upper about 1.977%; 0/139 gives 2.132%.
Shared facts can make the real independent count lower than the nominal base-ID count.

These intervals describe the declared sampling/fixture distribution, not a universal
robustness guarantee against an adaptive policy. Predeclare sample size, hazard mixture,
cluster rules and stopping policy. A locked suite exposed during tuning becomes development
data; use a new confirmatory suite instead of repeatedly claiming fresh confidence.

### 12.3 Grade, stability and coverage diagnostics

- Per-family TA/rejection/FA/unknown and sample/cluster counts, including low-n warnings.
- Paired valid-alternative/source/proof comparisons; acceptance alone does not prove
  no discount. Set a development-calibrated grade-parity tolerance before locking.
- Repeat a predeclared subset to measure eligibility flips and grade variation; do not
  assume temperature zero guarantees identical results.
- Wrong-vs-valid group ranking and adversarial invariance, not just scalar averages.
- Conditional unknown and latency rates by task length/operator, strict-correct status,
  proof size, policy version and queue load.
- Separate natural-rollout monitoring from balanced adversarial classification results.

### 12.4 Immutable run layout and completion

```text
<eval-root>/rgate/<protocol-hash>/<run-id>/
  manifest.json
  bundle-or-reference.json
  task-and-label-manifests/
  requests/<case-id>/<attempt>.json
  responses/<case-id>/<attempt>.json
  decisions.jsonl
  report.json
  completion.json
```

Save raw responses including finish reasons/usage, but redact credentials/authorization
headers. Record actual weight/tokenizer/image/patch hashes; `model=judge` is not a model
revision. Hash the source inventory because the working tree is uncommitted. Persist
per-case results incrementally and resume only with the identical protocol; never merge
partial results from incompatible versions.

Use storage-appropriate finalize semantics. Do not assume object/Volume renames have
POSIX atomic behavior. Write immutable blobs and a final completion marker only after
validating checksums/counts; readers consume finalized manifests, not changing filenames.

Suggested exit contract:

- 0: complete, integrity-valid evaluation that meets the applicable gate;
- 1: complete valid evaluation, thresholds failed;
- 2: invalid input/configuration, incomplete run or fatal infrastructure/protocol failure.

Also emit `execution_complete`, `label_integrity`, `gate_pass`, `approval_scope` and
reason codes to the job/MLflow report. A development-only pass cannot authorize production
training. Keep separate trainer completion manifests: requested/admitted groups, actual
optimizer steps, synchronization and checkpoint verification. Log-pattern guards are
secondary diagnostics, not the only proof of success.

**Acceptance:** all false-green probes fail before promotion; exact statistics and
coverage tests pass; interrupted/resumed jobs are reproducible; reports distinguish
threshold failure from execution failure without making failed gates green.

---

## 13. R10 — installed-image and GPU validation ladder

No new full TP16 run until the relevant CPU regressions and label checks pass. Proposed
job names below are NEW recipes, not existing validated jobs; allocate numbers/names at
implementation time. Do not relaunch air/82 unchanged.

| Stage | Workload/resources | Prerequisites | Required result |
|---|---|---|---|
| G0 | CPU/unit/property/mocked-service tests; candidate-image CPU self-test | R1–R9 components | fixed contracts; dependencies present; no skipped critical tests |
| G1 | Real Qwen tool/ledger capture, normally 1x8 H100, no optimizer | R3/R4/R8 adapter preflight | 2–4 prompt groups; actor-visible hashes/roles/masks/transport match offline replay |
| G2 | Full GLM-5.3 TP16 sanity + certified dev suite | certified starter labels; R5/R6/R9 | critical positives/negatives and failure paths behave correctly; no literal-value regression |
| G3 | 2x8 H100 answer-mode/fault-injection integration smoke | typed outcomes/admission CPU+G1 | actual unknown groups excluded; two full admitted batches, genuine updates/sync; not learning evidence |
| G4 | Locked full R suite + fresh natural-rollout audit | adequate independent data, sealed protocol, G2/G3 | all contract, TA/rejection/FA-upper/coverage criteria pass |
| G5 | Short grounded treatment + answer-only control | G4 and data/sandbox gates | controlled 2–5-step wiring/control test, checkpoint reload; no large learning claim |

Keep full TP16 for the judge; do not substitute a smaller model to make the plan cheap.
A live grounded configuration using 8 rollout + 8 trainer + 16 judge GPUs is normally
32 H100s under the existing disaggregated topology; the resolved allocation must be
checked before submission. Sequential rollout capture and offline judging can reduce
simultaneous resources for earlier stages.

Reuse one warm judge for sealed sanity/development stages when operationally practical,
but never edit its prompt/config underneath an active run. Judge load time is substantial;
CPU replay with frozen verdicts should isolate deterministic code changes before spending
that startup cost. Do not promise a GPU-hour total until the certified suite size and
operator/proof lengths are measured.

### 13.1 Candidate image/configuration

- Keep historical v7 immutable; create a distinct candidate tag/digest for integration
  patches. Pin the exact verl base commit and patch hash.
- Preserve the proven full-GLM serve/NCCL/Ray topology and the 8-turn, ~73k smoke budget
  unless a separate tested budget change is necessary. Record every resolved override.
- Rerun bubblewrap no-network/no-host-gold/process-timeout tests with numpy/pandas in
  the candidate image. Local missing-dependency skips are not a target-image pass.
- Assert the new loop, manager, task registry and group-admission implementation are
  loaded on every relevant worker. Reject conflicting legacy sitecustomize activation.
- Confirm actual per-turn/episode token limits, character limits and terminal behavior
  match eval; print fingerprints, not private gold data.

### 13.2 Required G2 cases

Include valid conversion/rounding, one-file multi-input calculations, valid alternate
bulletins, interior-year ranges, legal footnotes, late duplicate valid evidence, a
published aggregate and a permitted shortcut. Include forged prose/stdout/IDs, failed
reads, wrong units/period/vintage, missing vector entries and injected instructions.
Test just-under/over-context requests, malformed judge JSON and service failures.

Do not call a critical positive regression acceptable because FA fell. Do not interpret
U/F=0 accepts as a general provenance proof when labels/views remain uncertified.

### 13.3 Required G3 fault scenarios

Use real easy-question prompts and controlled verifier fault injection, clearly labeled
as integration testing. Cover one and all unknown siblings, transient recovery, persistent
outage, manager timeout, malformed status, duplicated/missing group results and dataset
exhaustion before the required admitted-group count.

Provision reserve generation attempts: 32 attempts do not guarantee 32 admitted groups.
Require two full 16-group admitted syncs for the two-step success claim. Log nonzero
advantage variance and actual PG gradients on at least one clean mixed group; if the
run produces only all-zero groups, report that part as inconclusive, not validated.

Check KL/entropy behavior, real optimizer/global-step counts, parameter sync, absence of
unknown rows in actor batches and a saved/reloadable checkpoint. The old smoke used
`save_freq=-1`; do not assume its two-step success proves checkpoint writing.

### 13.4 G4 scope and stopping

Collect a fresh natural monitoring set (target roughly 100 episodes, predeclared sampling)
under the frozen base/controller, separate from curated adversarial labels. Repeated
rollouts of the same questions measure behavior/coverage, not new-question independence.

If there are not enough independent certified validation clusters, G4 is BLOCKED. A
smaller finite-bank pass may support further diagnostics or a separately approved,
manually/deterministically certified answer-only overfit smoke—not a full R-gate claim.
If the semantic judge still fails on properly certified data, keep it diagnostic-only
or narrow the supported treatment scope openly; do not paper over failures with regexes.

---

## 14. R11 — learning controls and operational maintenance

After required R clearance, compare under one frozen controller/task/interface contract:

1. base model;
2. SFT-only on independently verified demonstrations if SFT is used;
3. strict typed answer-only RL;
4. verified-support graded RL.

Use identical initialization, real question set, answer interface, actor-visible tools,
rollout budgets and decoding for the RL comparison. If both start from SFT, use the same
checkpoint. Compare matched generated samples/tokens and resource cost; do not call a
tool/corpus/scorer change an RL gain.

Report benchmark metric, typed-answer accuracy, independent grounded-correct rate,
coverage/abstention, valid-proof acceptance, unknown/group-quarantine rates, per-family
results and cost. Report useful mixed-group rate and within-valid grade variation.
Select checkpoints on development data and disclose hard-set exposure. A confirmatory
transfer claim needs untouched questions/facts, not merely a new checkpoint scored by
the same judge used for training.

Before any larger run, load-test reward handling at an improved-policy correctness rate,
not only the current sparse-success rate. Measure queue age, p50/p95/p99 latency, pending
verification, refill attempts, policy lag and selection effects. Add circuit breakers
for persistent unknowns, schema drift, corpus mismatch, no-progress and unsafe model/
verifier changes. Never silently switch model, effort, prompt or failure policy mid-run.

Update the handoff after each package: exact code/test/artifact hashes, what ran on CPU
versus GPU, open failures, next commands and whether approval scope changed. Commit only
when the owner requests it.

---

## 15. File-level implementation map

Paths below are planned additions/changes unless marked existing. Avoid touching unrelated
math/benchmark recipes or the historical scorer.

| Area | Primary paths | Intended ownership |
|---|---|---|
| Protocol and task registry | new `scripts/officeqa/contracts.py`, `task_registry.py`, `quantities.py` | strict public/private task, episode, certificate and outcome schemas |
| Corpus semantics | existing `html_table_parser.py`, `chunker.py`, `build_chunks.py`; new `table_ir.py` | header hierarchy, source offsets, raw/normalized separation |
| Tool views | existing `scripts/tools/officeqa_tools.py`; new `observation_formatter.py` | typed status, whole-row payloads, exact cursor and delivered span |
| Runtime provenance | new `ledger.py`, `verl_agent_loop.py`, `agent_loop.yaml`, `episode_replay.py`; existing eval harness | controller authority, actual final events and parity |
| Answer/proof | existing `scripts/reward/strict_answer.py`; new `evidence_bindings.py`, `derivation.py`, `officeqa_verifier.py` | typed equality, reference resolution, bounded arithmetic |
| Judge | existing `judge_prompt.py`; new `semantic_judge.py` | blinded support-certificate proposals, strict schema, budget/cache |
| Reward adapter | existing `officeqa_grounded_reward.py`; new `officeqa_reward_manager.py` | shared verification, typed failures, graded assembly |
| Group admission | new `scripts/officeqa/group_admission.py`; replace production role of `quarantine.py`; retire new-mode `_site` activation | complete-group resolution before batching/losses |
| Pinned integration | new `docker/patches/` patch; candidate Docker build; existing launcher/dispatcher | admission/backpressure/completion hooks and version assertions |
| Data/cases | existing prep and generator; new `certify_cases.py`, `audit_task_splits.py` | real easy tasks, independent labels, split/visibility audit |
| Runner/artifacts | existing `rgate_run.py`; new `rgate_stats.py`, `rgate_artifacts.py`, `compare_rgate_runs.py` | integrity, exact uncertainty, immutable publication |
| Tests | `scripts/reward/tests/`, new `scripts/officeqa/tests/`, existing sandbox tests | positive + adversarial + actual transport/loss coverage |
| GPU recipes | new G1–G5 YAMLs under `air/`; historical air/82 retained | explicit staged validation with sealed manifests |
| Docs | this plan, `officeqa_rl_plan.md`, `officeqa_rgate_handoff.md`, pilot README | status, decisions, constraints and reproducible handoff |

### 15.1 Issue-to-repair coverage

| Review issue | Packages | Required proof of repair |
|---|---|---|
| Wrong mutation/positive labels and surviving alternate evidence | R7/R9 | certified proof/anti-proof pairs, source-visible audit |
| Bogus alternative dates and reporting-vintage confusion | R2/R3/R5/R7 | real alternative-source controls + typed vintage checks |
| Historical 3k loss and mismatched views | R3/R4 | fresh lossless delivered envelopes, no invented historical recovery |
| Literal-gold/period/two-line heuristic regressions | R5/R6 | conversion/rounding/range/vector positives and negatives |
| Single-file composition and unchecked semantic flags | R2/R5/R6 | task-plan coverage and strict semantic consistency |
| Compute/prose/marker/cross-episode forgery | R4/R5 | real trusted transport exploit tests |
| No-match read and snippet/listing confusion | R3/R4 | typed statuses and sufficient-snippet controls |
| Percent/scale/list/date answer weakness | R2/R5 | typed task-declared grammar and normalization tests |
| Outer timeout -> zero; incomplete group masking | R8 | installed manager + all-loss filtered-batch equivalence |
| Async refill/deadlock/false completion | R8/R9/R10 | 16-admitted-group progress and bounded exhaustion tests |
| Missing/duplicate/NaN score false-green | R9 | integrity rejection before statistics |
| False independence, unknown as rejection, no lockbox | R7/R9 | declared clusters, coverage, sealed data and exact bounds |
| Model/prompt/artifact drift and overwrites | R0/R6/R9 | immutable raw artifacts, hashes and strict resume |
| Source hierarchy, cursor and train/val overlap | R3/R4/R7 | page/view tests and split/retained-count assertions |
| Training smoke overstated as quarantine/learning/checkpoint proof | R10/R11 | separate measured completion and control evidence |

---

## 16. First implementation tranche and final acceptance checklist

### Start here — no GPU required

1. Verify/replay the archive; read the finalized attempt-4 review.
2. Implement R1 promotion guard and red regressions; do not replace archival code.
3. Agree/freeze R2 contracts and public/private task boundaries.
4. Build a tiny certified real-easy seed: conversion (UID0023 family), net calculation
   (UID0043 family), direct lookup, a real alternative source and a wrong-period proof.
   Historical UID examples are regression references; newly captured/certified episodes
   must establish the actual label before training use.
5. Implement typed results/ledger capture and answer/Stage-A proof resolution against
   these tasks. Use mocked judge proposals to test the complete path.
6. Implement outer failure transport and the admission state machine with the exact
   16-group backpressure simulation.
7. Harden runner integrity in parallel. Only then build the candidate image/G1.

Do not start by adding another quote regex, changing the judge model, increasing the
negative case count, lowering thresholds or relaunching air/82.

### Release checklist

- [ ] All critical positive and exploit regressions pass, not xfail/skip.
- [ ] Candidate image preserves the sandbox and scientific stack.
- [ ] Task specs, original-source semantics and actor-visible views are certified.
- [ ] Terminal commitment and every proof leaf use trusted runtime provenance.
- [ ] Correct calculations, units, periods and permitted shortcuts are accepted.
- [ ] Missing semantic requirements cannot be rescued by a numeric grade.
- [ ] Actual train/offline serialization and masks are equivalent.
- [ ] UNKNOWN survives all failure layers and no quarantined group reaches losses.
- [ ] Async admission/refill/exhaustion is bounded and cannot deadlock or false-pass.
- [ ] Runner refuses incomplete, duplicate, malformed and nonfinite data.
- [ ] Locked validation has adequate independent certified scope and meets thresholds.
- [ ] Unknown/coverage, repeatability and alternative-source grade parity pass.
- [ ] Raw artifacts and all model/protocol/source revisions are immutable and reproducible.
- [ ] Actual optimizer, synchronization and checkpoint/reload checks pass where claimed.
- [ ] Only then: short matched controls, independent evaluation, and a separate scale decision.

Until this checklist is supported by executed evidence, the approval state remains
**NO-GO**, regardless of job color or a lower false-accept point estimate.
