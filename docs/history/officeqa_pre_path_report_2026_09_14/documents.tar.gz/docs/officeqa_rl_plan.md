# OfficeQA GRPO RL — Execution Plan and Validation Gates

**Owner:** michael.shtelma · **Infra:** Databricks AI Runtime serverless GPU (`df1`, AWS/H100), verl v0.9.0 fully-async/disaggregated; last exercised image `michaelshtelma587/verl-megatron-air:v7` · **Last reviewed:** 2026-09-14 (UTC)

> **Current decision: NO-GO for grounded-policy optimization, large-scale RL or bulk synthesis.**
> Air/82 attempt 4 (`543029753940588`) is COMPLETE and FAILED: **16/80 labeled controls
> accepted; 5/242 labeled negatives accepted; case upper95 4.295%, base-ID upper 7.414%**.
> The labels are uncertified and sometimes wrong; the checker also has genuine defects.
> Of 62 scored control rejections, 55 came from literal gold-in-quote matching. This is
> a regression, not near-clearance. The answer-mode smoke completed two real optimizer
> steps, but did not validate grounded reward, actual unknown-group exclusion or learning.
>
> **Authoritative immediate implementation plan:** `docs/officeqa_rgate_recovery_plan.md`.
> **Next-agent entry point:** `docs/officeqa_rgate_handoff.md`.
> **Final review/evidence:** `officeqa_pilot_records/rgate_review_2026_09_14/`.
> These supersede older readiness claims and the old prompt-recalibration loop below.
> Recovery code is **not implemented**. Preserve all historical artifacts and unrelated
> uncommitted changes; no commits unless requested.

---

## 0. Goal & success criteria

**Goal.** Demonstrate a practically useful, statistically credible improvement of
**Qwen3.5-35B-A3B** on grounded document reasoning, attributable to learning rather
than a changed harness, permissive answer matching, memorized facts, or judge exploitation.

**Why OfficeQA.** The task exercises retrieval, table interpretation, temporal
reasoning, and computation. There is substantial observed headroom, but its cause
must be diagnosed before assuming GRPO can exploit it. The saved trace run scores
**13/133 hard (9.8%) with the legacy local scorer**, not the previously reported
12.0%; most failures are abstentions or missing answers (§2.1).

Published frontier-agent results are **context, not an apples-to-apples target**.
The March 9, 2026 OfficeQA paper reports that 22% of Pro questions involve external
web values and 3% involve visual reasoning. Its full-corpus, parsed-document Opus
4.6 configuration averages 68.5 tool calls. Our current five local text/calculation
tools and 16-turn controller have materially different capabilities and budgets.
Choose and disclose the capability setting before the next paired baseline (§8.4).

**Definition of done.**
- Report base → SFT-only → RL results under one frozen evaluation contract, including
  the pinned benchmark scorer, a stricter typed-answer metric, and **independently
  evaluated grounded-correct rate**, all over the full evaluation denominator.
- Pre-register a practically meaningful target; **+10 percentage points** on the
  133-question Pro set is a proposed engineering target, not a promised result.
  Require a positive paired confidence interval as well; a net question count alone
  does not establish significance. Report wins, regressions, and run-to-run variation.
- Report coverage, explicit abstentions, missing/invalid answers, token/turn budgets,
  forced-final frequency, and cost per grounded-correct answer. Accuracy among attempted
  answers is a diagnostic, **not** the headline.
- Select checkpoints on development data. Do not evaluate every checkpoint on Pro.
- Treat OfficeQA Pro as **held out from project training but development-exposed**:
  its questions/labels/trajectories already informed harness and reward changes.
  A confirmatory transfer claim needs an additional untouched, independently authored
  test set with held-out facts/series, preferably another document family.

**Non-negotiable requirements.**
1. **Honest separation.** Keep hard/Pro, locked-validation questions and evaluation-only
   trace demonstrations out of training. The owner explicitly allows existing **easy**
   questions for a declared, certified training/development split; bulk synthesis is
   deferred. Audit fact/series aliases as well as UIDs. Neither text filtering nor
   train/eval UID disjointness makes an evaluator-development-exposed set untouched.
2. **Auditable gold.** Python verifies arithmetic, not the meaning of the selected
   cells. Verify headers, units, periods, revisions, and question semantics independently.
3. **Frozen comparison.** Pin data, corpus transform, prompts, tokenizer/template,
   tools, scorer, decoding budgets, and model revisions. Any harness change requires
   a new base evaluation under that same contract.
4. **Verifiable support.** Optimize an observable evidence-and-calculation contract,
   not an LLM's impression of the agent's hidden reasoning. Invalid evidence receives
   no positive terminal reward; verifier failures are not converted into success.
5. **Small experiment first.** Prove data quality, reward behavior, and useful learning
   on 100–300 gold tasks before building thousands of questions or launching ~48 H100s.

---

## 1. Target architecture

```text
Measurement + sandbox + tool/trace repairs ──> frozen base + failure diagnosis
                         │
                         ▼
Source JSON / original pages ──> semantic atoms + provenance + source-view checks
                         │        independent review, not just panel agreement
                         ▼
Existing real easy questions + typed task/proof specs ──> certified small bank
                         │
             semantic/fact split + ambiguity/contamination audit
                         │
                         ├──> demonstrations / development set / canary suite
                         ▼
Strict answer + trusted evidence ledger + deterministic derivation verification
                         │                    │
                         │             blinded semantic auditor only when needed
                         ▼
Small controlled training: SFT-only / answer-only RL / verified-support RL
                         │
            reward calibration + learning + throughput gates
                         ▼
Scale data and fully-async training ──> dev-selected checkpoint ──> frozen final eval
```

**Corpus separation.**
- **Retrieval view:** the existing `treasury_bulletins_clean.zip` (697 `.txt` files),
  currently chunked in-job into 123,107 BM25 chunks. Do not use the known
  `pd.read_html`-garbled `treasury_bulletins_transformed.zip`.
- **Gold-construction view:** pre-flatten JSON HTML tables from HF
  `databricks/officeqa`, with original page references for independent checks.
  Do not assume this parsed view is error-free simply because it is called clean.
- **Gold/reward isolation:** answer keys, atom bank, evaluator internals, credentials,
  and rendezvous files must not be readable by the policy's compute execution.
- **Runtime evidence view:** an immutable, per-episode ledger of the **exact content
  delivered to the actor after all truncation layers**, including successful/error
  status, call ID, document hash, visible spans, headers, units, and continuation cursor.
  Full source data may be archived separately but must not be counted as evidence
  the actor saw. Flat `solution_str` remains useful for debugging, not provenance.

**Model/annotation roles for the current tranche.**
- Trained subject: Qwen3.5-35B-A3B, exact model/tokenizer revision to be manifested.
- Semantic auditor: the owner's full self-hosted GLM-5.3 at TP16, frozen per protocol;
  propose evidence bindings for deterministic verification, not a persuasive transcript score.
- Independent source/label reviewers: must be assigned before certification. Different
  model providers or unanimity are not independence or a substitute for original-page audit.
- Question generation and a paid multi-provider panel are **not prerequisites** for the
  real-easy recovery bank. Do not assume unverified model availability or launch those jobs.

---

## 2. Current status (2026-09-14 UTC)

Jobs API statuses were rechecked at **2026-09-14T10:58:22Z**: all reviewed air/82
attempts and the answer-mode smoke are terminal. Air/82 attempts 2/3/4 completed
scoring and failed thresholds; attempt 1 failed on a scorer import bug. The latest
review used archived/live-fetched artifacts and CPU probes; it launched no additional
GPU job. Raw reports, hashes and the exact scope of each claim are in the review archive.

| Component | State |
|---|---|
| Checkpoint save (35B → loadable HF, no OOM) | ✅ previously validated, run 410679584424844 |
| Fully-async multi-turn + HTTP judge infrastructure | ✅ previously validated, air/53 run 864953242920662 |
| HF fetch / corpus staging / local retrieval | ✅ built and exercised; ⚠️ semantic/cursor contracts still need repair |
| Compute tool | ✅ executes calculations; ✅ **bubblewrap OS boundary implemented + verified 2026-09-13**: fresh child in user/mount/net namespaces, no network, corpus/model/benchmark/home mounts masked, SIGKILL timeout, per-process stdout, fail-closed unless explicitly opted out. CPU contract 11 pass + 2 dependency skips; v7 pushed/registered; df1 `air/80` run 510519807483794 proves userns and bwrap (without nested `/proc`) work and network is denied |
| Eval harness + trace capture | ✅ runs; ✅ abstention/coverage/termination accounting + scorer-drift reconciliation now reproducible (`scripts/officeqa/measure_traces.py`, pinned scorer); **⛔ lossy traces (3k clip) and train/eval parity still unresolved** |
| Original `air/71` baseline | Historical report: 16/133 hard (12.0%), 35/113 easy, 51/246 total; reconcile against original per-question artifact |
| Saved `air/72` trace baseline | **13/133 hard, 38/113 easy, 51/246 total** with legacy local scoring (§2.1) |
| Grounded reward v2 (fuzzy gate, fail-open) | Superseded; **⛔ not approved** (§6.1) |
| Current grounded reward/checker (v2.1) | ⛔ not safe: literal-value regression, incomplete typed units, compute/prose/marker trust defects, file-count composition and train/offline mismatch; 12/43/18 existing tests pass despite reproduced failures |
| Judge pilot | Infrastructure exercised; genuine semantic accuracy not established by the uncertified labels |
| R-gate first pass (air/79, run 340221642696128) | Historical 8 resolved + 1 unknown smoke; expanded runs replayed the handbuilt cases. RG07 scores 1.0 in attempt 4, but that does not validate the broader alternative-source class |
| R-gate EXPANDED (air/82) | **COMPLETE, FAIL**: attempt 2 controls 78/80, labeled-negative accepts 121/220; attempt 3 63/80 and 72/220; attempt 4 (`543029753940588`) **16/80 and 5/242**, case upper95 4.295%. Labels and independence assumptions also fail audit |
| GLM-5.3 TP16 judge serving | ✅ exercised through air/82; whole saved trajectory is sent, but original 3k recording loss remains; exact token-budget, raw-output/version and online failure contracts still need repair |
| Strict answer / evidence / derivation contract | ⛔ partial legacy implementation only; typed TaskSpec, authenticated ledger and bounded proof engine are recovery packages R2–R6, not implemented |
| Adversarial, independently labeled reward validation | ⛔ legacy bundles are development diagnostics, not certified validation; rebuild labels/views, lock splits, and obtain sufficient independent scope before the full gate |
| Unknown-group handling | ⛔ sentinel/advantage patch loaded in the smoke, but outer timeouts bypass it and KL/denominator effects survive; true pre-batch group admission is R8 |
| Small gold bank + controlled learning pilot | Answer-mode run `616024033111491` completed **two real optimizer steps**. Certified bank, grounded treatment, checkpoint/reload and learning-control evidence remain open |
| Bulk synthesis / large RL / final claim | ⛔ gated on small-pilot evidence |

### 2.1 What the saved trajectories actually show

Measured from `officeqa_pilot_records/officeqa_traces.jsonl`:

| Metric | Full (246) | Hard (133) | Easy (113) |
|---|---:|---:|---:|
| Legacy exact correct | 51 (20.7%) | 13 (9.8%) | 38 (33.6%) |
| Explicit `DATA NOT AVAILABLE` | 158 | 97 | 61 |
| Missing extracted answer | 12 | 9 | 3 |
| Substantive attempted answer | 76 | 27 | 49 |
| Reached 16-turn cap | 179 | 110 | 69 |

Thus 170/195 legacy-scored failures have **no substantive answer**. This contradicts
“misses are wrong-not-blank”; it does not prove that every abstention is a retrieval
failure. Diagnose retrieval, evidence visibility, external-data requirements, stopping,
interpretation, and arithmetic separately. Equal aggregate 51/246 totals do **not**
prove that `air/71` and `air/72` reproduced one another or that tracing is non-perturbing.

These numbers are now produced by a **reusable, reproducible** script
(`scripts/officeqa/measure_traces.py`) that any arm (base/SFT/trained) runs to emit an
immutable manifest (bundle + scorer hashes + the stat block). It also clarified a metric
definition: the bundle's `truncated` flag marks the **12** trajectories with no extracted
final answer (9 hard), which is a *different* signal from **179** trajectories that
reached the 16-turn cap (110 hard) — most cap-reachers still committed an answer (usually
an abstention). Reported separately now, not conflated.

**Reconciliation `air/71` ↔ `air/72` — DONE 2026-09-13, and it settles the §2.1 warning:
the two baselines did NOT reproduce each other per-UID.** `scripts/officeqa/reconcile_runs.py`
(reusable; also the base→trained pairing tool) matched all 246 UIDs and found **only
170/246 predictions identical (76 diverged, 31%)** even though both runs decode at
temperature 0. Under the pinned scorer each run posts ~51 correct, but the McNemar table
is **both-correct 33, air/71-only 18, air/72-only 19, both-wrong 176 → 37 discordant
questions**. The matching aggregate (51 vs 52) was therefore a coincidence over large
per-UID churn — vLLM greedy is not batch-deterministic, and `air/72` additionally had
tracing on. **Consequence for the whole goal:** run-to-run correctness noise (~37 flipped
questions on the full 246-question set. This is run-to-run churn, but it is **not** a
37-question standard deviation and does not by itself dwarf the hard-set target. On the
133 hard questions under the pinned scorer, the paired table is **both-correct 6,
air/71-only 10, air/72-only 8, both-wrong 109** (16→14, 18 discordant; exact McNemar
p≈0.815; illustrative independent-question paired SE≈3.2pp). The runs also differ in
tracing and lack complete code/runtime manifests, so vLLM batching is a plausible cause,
not a proven attribution. Repeated base evaluations and paired same-question comparisons
remain mandatory; repeated observations of the same questions are not independent test
questions. Manifest: `officeqa_pilot_records/air71_vs_air72.reconcile.json`.

Additional measured/tool-contract findings:
- 424/1,571 grep calls returned no matches. 187 calls used obvious regex-like syntax
  without enabling regex; 185 of those returned no matches. The ~0.1% tool-exception
  rate therefore does not mean the tool interactions were effective.
- A toy `_read_document(..., 0, 100)` call advertised lines 0–99 but its 4,000-character
  clipping cut the output in row 35. Paging by the advertised end would skip unseen rows.
- Every saved trace contains a tool output cut at 3,000 characters. The actor could
  receive more text than was recorded. Of 3,335 recorded outputs, 1,987 hit that cap.
- 241/246 rendered trajectories exceed the judge's 12,000-character window; **47/51
  correct trajectories** do. Truncation is the common path, not a rare exception.

**Scorer drift is also measurable.** The upstream OfficeQA `reward.py` snapshot
inspected on 2026-09-13 includes direct-answer, ordered-list, and explicit-unit checks
missing from the local port. Re-scoring the same saved predictions with that snapshot
produces **52/246 overall, 14/133 hard**: UID0148 (`[28, 2444.28]` versus `28,2444.28`)
changes from wrong to correct. This is a scorer change, **not a model improvement**.
Pin the chosen revision/hash and re-score both arms; do not silently replace historical
scores. Snapshot hash and primary sources are recorded in §11.

---

## 3. Jobs and execution order

Submit GPU jobs with `air run --file <yaml> -p df1`; inspect with `air get run <id> -p df1`
and `air logs <id> -p df1`. Preserve the existing operational lessons: status matching
must handle mixed case and only stop on terminal states; background bash monitors have
been memory-killed. UC CLI listings need `dbfs:/Volumes/…`; use a job's FUSE mount for
bulk transfer rather than repeatedly uploading through the throttled Files API.

### Completed jobs (historical)

| Job | Air file | Compute | Record |
|---|---|---|---|
| J-fetch | `air/03_fetch_officeqa_hf.yaml` | 1×A10 | CSVs staged; JSONs via `FETCH_JSONS=1` |
| J-smoke | `air/70_eval_officeqa_smoke.yaml` | 8×H100 | Toolchain smoke, not semantic/sandbox validation |
| J-base | `air/71_eval_officeqa_base.yaml` | 8×H100 | Run 131584319713753; original hard result needs reconciliation |
| J-trace | `air/72_eval_officeqa_trace.yaml` | 8×H100 | Run 812185057840663; 246 lossy historical traces |
| J-judge | `air/73_officeqa_grounding_judge.yaml` | 16×H100 | v2 run 816553954005618; 100 historical score records |

`air/71`/`air/72` use TP8, `EVAL_SERVE_LEN=49152`, `--disable-custom-all-reduce`,
`EVAL_CONCURRENCY=32`, 16 turns, temperature 0, and a prefix-forced final answer.
These are historical settings, not proof that the stock training loop behaves identically.

### Planned work (new files below are still proposals)

| Job | File / execution | Purpose | Gate |
|---|---|---|---|
| J-repair | Local CPU tests + harness changes | Strict scoring, sandbox isolation, table/cursor repair, trustworthy evidence capture | M + S |
| J-diagnose | Reuse `air/70`/`air/72` on development tasks | Full retrieval vs oracle-file/table/atom diagnostic; budget sensitivity; new frozen base | M |
| J-atoms-small | `air/74_officeqa_atoms.yaml` | A small, independently audited semantic atom bank | D |
| J-synth-small | `air/75_officeqa_synth.yaml` | 100–300 gold questions/proofs; no initial silver | D |
| J-band | `air/76_officeqa_band.yaml` | Stochastic pass-rate estimates and actual informative-group rate | D |
| J-adv | Reuse `air/73` with new validation bundle | Labeled counterfactual/matched-pair reward suite, including real training serialization | R |
| J-train-small | `air/77_officeqa_train_smoke.yaml`, deliberately short | ✅ Training integration smoke DONE (run 616024033111491: 2 real optimizer steps, reward variance, quarantine patch loaded); next: judged grounded-mode run after Gate R passes | L |
| J-eval-dev | `air/78_officeqa_eval_trained.yaml` | Development-only checkpoint selection | L |
| J-scale | Expand above jobs, only after gates | More data and ~48×H100 trainer/rollout/judge topology if justified | T |
| J-final | Frozen selected checkpoint + base | Pro and untouched confirmatory evaluation, not checkpoint hill-climbing | E |

**J-train implementation contract.** Preserve the proven Megatron trainer / vLLM
rollout separation and save→HF export. Before training, test the *actual installed*
verl reward-manager and ToolAgentLoop with trusted evidence boundaries. Do not infer
parity from sharing five Python tool functions. `OQ_REWARD_MODE=answer` is now a real
answer-only control in CPU tests, but the first GPU smoke must prove the decoded
`solution_str`, reward invocation, masks, budgets, and group handling in-container.

If the semantic auditor is needed, reuse full GLM-5.3 at TP16 via the proven rendezvous
pattern. GLM-5.3-Flash co-serving was reported unsuccessful; do not assume it is a drop-in
cost reduction. Conversely, do not reserve 16 judge GPUs for deterministic-only controls.
Judge work increases as the policy becomes correct more often; it is not bounded by
its low initial pass rate (§6.6).

---

## 4. Scripts inventory and required changes

| Script | Current role / required action |
|---|---|
| `scripts/officeqa/fetch_officeqa_hf.py` | Existing HF → Volume staging; add revision/content manifests |
| `scripts/eval_officeqa_agentic.py` | Existing eval; fix abstention accounting, lossless actor-visible trace, terminal reasons, shared controller contract |
| `scripts/tools/officeqa_tools.py` | Existing search/grep/read/list/compute; fix cursor/whole-row visibility, explicit regex behavior, source spans and response metadata |
| `scripts/tools/py_compute.py` | Prototype execution only; replace thread/AST pseudo-sandbox with actual isolation and killable limits |
| `scripts/officeqa/html_table_parser.py` | Preserves many numeric strings, but loses parent header meaning in colspan flattening; structural regression tests required |
| `scripts/officeqa/build_chunks.py`, `chunker.py` | Preserve table/heading/unit context and stable document/table/span identifiers through indexing |
| `scripts/reward/officeqa_reward.py` | Legacy scorer with exploitable matching; pin/update benchmark scorer and implement separate typed training checks |
| `scripts/reward/answer_extract.py` | Restrict reward extraction to the committed assistant answer, never tool output or arbitrary reasoning tags |
| `scripts/reward/grounding.py` | Current file-engagement/hygiene diagnostics are **not evidence authentication** |
| `scripts/reward/judge_prompt.py` | Replace permissive parse/defaults and answer-anchored route rubric with strict, blinded semantic judgments |
| `scripts/reward/officeqa_grounded_reward.py` | Replace fail-open v2 formula; implement real mode branching and explicit invalid/unknown states |
| `scripts/score_trajectories.py` | Preserve raw judge reply, versions, input coverage, labels, sampling strata, and group-level diagnostics |
| `scripts/reward/judge_reward.py` | Reuse endpoint/session resolution only; its fallback policy is not a grounding guarantee |
| `scripts/serve_judge.sh`, `scripts/lib/ray_cluster.sh` | Existing TP16/Ray serving; retain operational recipe |
| `scripts/dispatch_agentic.sh`, `run_grpo_fully_async.sh` | Existing launchers; assert resolved limits, masks, group completeness, reward version, and policy staleness |
| `scripts/serve_and_eval.sh` | Existing staging/serving; emit the same versioned evaluation manifest for base and trained models |
| `extract_atoms.py`, `verify_atoms.py`, `compose_questions.py`, `render_questions.py`, `validate_questions.py` under `scripts/officeqa/` | Not built; start small, with semantic provenance and end-to-end solvability validation |
| `band_difficulty.py`, `contamination_audit.py` under `scripts/officeqa/`, `scripts/prep_officeqa_tool_agent.py` | Not built; data splits, uncertainty-aware banding, and strict training schema |
| Evidence schema/verifier + regression/integration tests | New implementation needed; suggested tests and acceptance criteria in §10 |

---

## 5. Data, model, and experiment artifacts

| Path | What |
|---|---|
| `/Volumes/main/mshtelma/verl/models/Qwen3.5-35B-A3B` | Base model; pin actual revision/tokenizer hash |
| `/Volumes/main/mshtelma/verl/models/GLM-5.3` | Existing reward-auditor model staging; historical TP16 serving recipe |
| `/Volumes/main/mshtelma/verl/models/GLM-5.3-Flash` | Staged alternative; reported co-serving incompatibility, not the selected judge |
| `/Volumes/main/mshtelma/verl/data/officeqa/officeqa_full.csv` | 246 questions: 133 hard + 113 easy; preserve dataset revision/hash |
| `/Volumes/main/mshtelma/verl/data/officeqa/officeqa_pro.csv` | Training-excluded but development-exposed public evaluation set |
| `/Volumes/main/mshtelma/verl/data/officeqa/treasury_bulletins_clean.zip` | Current retrieval view; needs semantic/header audit before atom scaling |
| `/Volumes/main/mshtelma/verl/data/officeqa/treasury_bulletins_transformed.zip` | Known garbled variant; **do not use** |
| `treasury_bulletins_parsed/jsons/*.json` (HF, `FETCH_JSONS=1`) | Gold-construction input, not automatically trustworthy ground truth |
| `/Volumes/main/mshtelma/verl/eval/officeqa_traces.jsonl` | Historical trace output; do not overwrite when regenerating full evidence |
| `/Volumes/main/mshtelma/verl/eval/officeqa_grounded_scores.jsonl` | Historical scorer output; use versioned paths for new experiments |
| Repo `officeqa_pilot_records/` (currently untracked) | Immutable local v1/v2 records and historical reports; README carries review corrections |
| `/Volumes/main/mshtelma/verl/rendezvous/` | Cross-node judge discovery; inaccessible to policy compute |
| New per-run manifest / evidence ledger / raw judge outputs | Required before the next baseline or learning run |

Each new run must record: code commit **plus dirty diff or snapshot hash**, dataset and
corpus hashes, transform/index version, atom-bank/split version, model and tokenizer
revisions, chat-template hash, complete resolved config, system prompt/tools, answer extractor,
benchmark and training scorer hashes, judge model/prompt/parser versions, seeds,
policy versions, all token/character/turn limits, and resource/cost measurements.
A model display name or mutable `main` branch is not a reproducibility identifier.

---

## 6. Reward design — from v2 route grading to verified support

### 6.1 Existing v2 behavior: historical prototype, not training approval

The current `officeqa_grounded_reward.py` implements:

```text
wrong / absent according to legacy score_answer(tolerance=0) -> 0
otherwise:
    route = judge.route_score
            or file-engagement fallback when judgment fails
    route <= 0.20 -> 0.05
    otherwise -> clip(0.30 + 0.50*route + 0.20*trajectory_quality, 0.30, 1)
```

**Reproduced blockers:**
- **“Exact” is not strict correctness.** The local scorer accepts `500 or 507 or 509`
  for gold `507`, swaps the two outputs of `[34.4, 0.391]`, accepts one `1` for
  `[1, 1]`, accepts `543 billion` for `543 million`, and parses `1e9` as matching `1`.
  Tolerance 0 does not repair structural or unit errors.
- **Fallback fails open.** A correct-number trajectory with a failed read or a
  no-match grep targeting the gold filename gets **reward 1.0** when the judge is
  unavailable. `grounding.py` counts requested filenames, not successful supporting cells.
- **Parser repairs can invent certainty.** `{"verdict":"grounded"}` defaults to
  route 1 and true support flags; the string `"false"` becomes true through `bool(...)`;
  NaN can normalize to 1. The brace scanner also ignores JSON string quoting.
  A contradictory `lucky_wrong_source`/route-1 verdict is not rejected by `_assemble`.
- **Unknown is highly rewarded.** With hygiene 1, route 0.5 gets 0.75. The support and
  completeness booleans do not constrain the scalar reward. Missing evidence is not
  equivalent to a slightly lower-confidence success.
- **The advertised ablations are not implemented.** `_MODE` controls whether the judge
  runs, but all paths still call `_assemble`. A correct bare answer under mode `answer`
  gets 0.05, not 1.0. Offline scoring also needs explicit, tested mode semantics.
- **Flat and structured paths differ.** Equivalent XML serialization of the saved
  steps changes hygiene reports for 33/246 traces because the text path lacks duplicate
  signatures. Raw text can also impersonate tool outputs. Test the actual training
  representation; this synthetic serialization probe is not an end-to-end verl test.

### 6.2 GRPO changes the meaning of the reward scale

The inspected verl v0.9.0 implementation defaults to within-prompt standard-deviation
normalization. The local launcher selects GRPO without overriding that default:

```text
A_i = (r_i - mean(group_rewards)) / (std(group_rewards) + epsilon)
```

A local numerical probe using sample standard deviation gives approximately:

```text
rewards [0, 0, 0, 0.05]       -> advantages [-0.5, -0.5, -0.5, +1.5]
rewards [0, 0, 0, 1.00]       -> advantages [-0.5, -0.5, -0.5, +1.5]
rewards [0.95, 0.95, 0.95, 1] -> advantages [-0.5, -0.5, -0.5, +1.5]
```

Consequences:
- A positive “lucky floor” is **not a small learning signal** when it is the group's
  only positive outcome. Invalid evidence must receive the same zero terminal reward
  as other failures in the initial grounded experiment.
- Small uncalibrated 0.85/0.90/0.95 differences can drive substantial updates in
  all-correct groups. Do not optimize judge confidence, verbosity, or file conformity.
- Smaller route/hygiene weights are not sufficient protection against normalization.
- Down-weighting every reward of a silver question equally also largely cancels.
  Confidence weighting belongs in sampling or an explicit post-normalization loss weight.

**Because the owner-selected reward is GRADED (§6.4), std-normalization MUST be OFF:
set `algorithm.norm_adv_by_std_in_grpo=False`** (verl v0.9.0 `core_algos.py:500` reads
`config.get("norm_adv_by_std_in_grpo", True)`; False switches `(r−mean)/std` to the
mean-baseline `(r−mean)`). This is now a **required** config, not a later ablation: with
std-norm ON the graded scale is erased inside a group (the illustration above), so the
grade could not do its job and the removed 0.05 floor would have reinforced as hard as a
real 1.0. Still: no positive lucky floor (it is 0.0), inspect actual group advantages,
add efficiency shaping only later as a separately tested term, and preserve proper group
IDs and all siblings — never substitute singletons because a slow positive rollout is
still awaiting judgment. A verifier `unknown` quarantines the whole sibling group.

### 6.3 Historical pilot and corrected interpretation (2026-09-13)

**Method.** `air/72` produced 246 base-model traces. `air/73` scored a stratified 100:
all 51 correct according to the legacy scorer plus 49 sampled wrong answers. The
pilot's selected distribution is not the natural correctness distribution, and each
question has only one sampled trajectory rather than a GRPO sibling group.

| Metric | v1 | v2 |
|---|---:|---:|
| Judge verdict parsed by the permissive parser | 62/100 | 99/100 |
| Legacy-correct records receiving the 0.05 floor | 15/51 | 0/51 |
| Mean reward on legacy-correct records | 0.688 | 0.956 |

Exact v2 route counts among the 51 correct records:
**14×1.00, 8×0.95, 17×0.90, 10×0.85, 1×0.80, 1×0.50**.
The earlier 0.8/0.9 summary bins were rounded and should not be presented as exact values.
There are 50 `grounded` verdicts and one `wrong_but_reasonable` (UID0002), not 51
unqualified grounding approvals. All 51 have support=true; 50 have completeness=true.
Hygiene is 1.0 on 49/51 correct records, so it contributes little differentiation here.

**Useful engineering lessons retained:**
1. Exact gold filenames are not the only legitimate sources: bulletins republish
   historical series. Removing the hard file-miss gate rescued 15 previously floored
   records. This is a necessary correction, not independent proof that every rescue
   has the right row, vintage, qualifiers, and derivation.
2. The rerun changed judge reasoning effort to `high`, raised the completion budget
   to 10,240, and broadened parsing, improving parsed responses from 62 to 99. This
   validates a serving/parser improvement, not the semantic truth of the verdicts.

**Why the reward is not yet validated:**
- No measured sensitivity to independently labeled **right-answer/wrong-evidence**
  cases. A route-score spread and separating wrong from correct answers do not prove
  this conditional capability. A single planted lucky success would still be insufficient.
- Most judge inputs omit evidence twice: outputs were recorded at 3,000 characters,
  then the rendered transcript was reduced to a 4,000-character head and 8,000-character
  tail. For UID0167 the judge explicitly says the 1950 read is in the truncated portion,
  yet marks all components retrieved and supported (reward 0.925).
- The auditor sees the correct final answer and the agent's explanation. It may infer
  missing evidence from answer agreement or persuasive notes instead of tool observations.
- Alternative-source bias remains: e.g. UID0081's judge reason describes the different
  bulletin as its only gap, assigning 0.85 despite identifying the same requested cell.
  Conversely, some questions genuinely constrain reporting vintage; do not blindly
  treat every reprinted series as equivalent.
- Natural greedy base traces are not the distribution an optimizing policy will
  produce. Judge exploitation, output stuffing, long-context attacks, and group ranking
  have not been tested. The value of an expensive judge over strict answer-only RL is
  still an empirical hypothesis.

Keep `validation_report_v2.txt` as a historical report, not an independent label set.
Reviewers must inspect source evidence rather than accept the judge's reasons as gold.

### 6.4 Reward contract: answer + evidence + derivation

**2026-09-14 recovery update:** the historical Tier-1 judge-audit below is **not
approved**. Air/82 attempt 4 confirmed a severe positive-acceptance regression and
exposed more label/proof defects. The immediate implementation is now specified in
`docs/officeqa_rgate_recovery_plan.md`: typed TaskSpec, controller-owned delivered
observations, evidence-first certificate proposals, checked arithmetic and whole-group
admission. The owner-selected reward remains **graded**, not binary. The proposed
first recovery interface retains the actor's final-answer tag; the judge proposes
bindings, and code checks them. It does not require a new actor proof language initially.

**Objective:** an auditable answer supported by observations. A certificate cannot
prove which hidden thought causally produced an answer; use counterfactual evidence
changes to test dependence on retrieval rather than claim to read the model's process.
A wrong original answer/abstention does not establish a wrong remaining evidence route.

**Historical Tier-1 design decision (kept for provenance; not a current readiness claim):**

> **Owner decision (2026-09-13): implement the PATCHED JUDGE-AUDIT reward, GRADED (not
> binary), FAIL-CLOSED.** The heavy evidence-ledger below (parts B/C: per-operand
> observation IDs + a submitted derivation graph) is the *escalation path* if the
> patched judge-audit reward fails the R-gate — it is not what we build first. What is
> built now (Tier-1, done + unit-tested in `scripts/reward/tests/test_reward_contract.py`):
> a strict typed answer GATE (`strict_answer.py`, part A), the GLM-5.3 route audit
> (`judge_prompt.py`, part D) as the grader, and deterministic fail-closed guards
> (`grounding.py`). The reward VALUE is the graded curve below, not R∈{0,1}:
>
> ```text
> pred = strict-parse(<FINAL_ANSWER>)      # arity/order/unit/exact; NOT the fuzzy benchmark scorer
> answer wrong / absent / malformed:                         R = 0.0     # gated; no dense shaping for wrong
> answer strictly correct -> the JUDGE is REQUIRED for any positive, then FAIL-CLOSED:
>   judge unavailable / verdict unusable (NaN/contradiction): status "unknown" -> retry/quarantine
>   no real retrieval at all (deterministic floor):          R = 0.0
>   judge: answer NOT supported by retrieved cells:          R = 0.0
>   composite & NOT all components retrieved:                R = 0.0
>   route <= 0.20:                                           R = 0.0     # lucky / wrong-route
>   else:                       R = clip(0.30 + 0.50*route + 0.20*traj_quality, 0.30, 1.0)   # GRADED
> ```
>
> **REQUIRED pairing:** GRPO std-normalization OFF (`algorithm.norm_adv_by_std_in_grpo=False`,
> §6.2) so the graded scale propagates. The old v2's 0.05 lucky floor is now **0.0** and the
> judge-outage fail-open to 1.0 is removed. `strict_answer.strict_correct` rejects all five
> confirmed scorer exploits; `parse_verdict` never invents certainty (missing route, NaN,
> string-boolean, and contradictory verdicts all resolve to `unknown`).

**A. Strict answer contract.**
- Keep a single committed `<FINAL_ANSWER>` value/list/date for benchmark compatibility;
  put the structured evidence/derivation submission in a separate field or action.
- Parse only the terminal assistant submission, not answer tags printed by a tool or
  found in reasoning. Enforce scalar/list arity, order or named fields, and no candidate lists.
- Carry the question's requested unit, scale, sign, percent-vs-ratio convention, and
  rounding rule into the training schema. Compare canonical values with Decimal/rational
  arithmetic or justified operation-specific numeric error bounds, not a generic 5% band.
- Pin the benchmark scorer separately. Maintain regression cases for zero, negatives,
  accounting notation, years, scientific notation, repeated list entries, and rounded ratios.

**B. Authentic evidence bindings.**
- Each claimed operand/fact cites a runtime-issued observation ID and visible cell/span.
  The verifier resolves values from the immutable ledger rather than trusting numbers
  retyped by the policy. Include row/column header paths, title, units, footnotes, period
  type (FY/CY/month/as-of), geography/entity, and reporting vintage when required.
- A failed call, empty grep, search listing, filename mention, or fabricated “tool output”
  is not supporting evidence. A complete search snippet may legitimately suffice;
  requiring a particular tool choreography is not the objective.
- Treat all policy text and retrieved text as untrusted content, never evaluator instructions.
  Model-authored compute stdout is not authenticated source evidence.
- Accept equivalent sources and valid alternative derivations. **Do not replace a file
  whitelist with an atom whitelist:** a published aggregate may validly replace several
  component reads. Verify the requested claim and the submitted proof's necessary inputs,
  not traversal of the generator's one reference path. Vintage/definition differences
  require explicit resolution, not value equality alone.

**C. Deterministic derivation verification.**
- Submit a bounded expression/operator graph over bound evidence variables. Recompute
  the result and unit conversions deterministically; validate operator semantics against
  the question, including sample/population statistics and intermediate rounding policy.
- Do not accept `print(gold_number)` as a derivation just because it ran in `compute`.
  Constants and alternate algebra must be justified by the task, not used to bypass inputs.
- This is a cheap verification of a small calculation, **not** an LLM re-running the
  entire research trajectory. Preserve the decision not to build full judge tool replay.
- Add support incrementally: start with identity/sum/difference/ratio tasks that can
  actually be verified, then expand operators after their contracts and tests exist.

**D. Semantic auditor for the unresolved remainder.**
- Where the deterministic evidence map cannot establish category/period/qualifier
  equivalence, give the auditor the question, claimed bindings, and complete source
  windows. Initially hide reference final number, match status, and free-form agent
  reasoning. Judge semantic support before combining with numerical correctness.
- Require a strict typed result: `valid`, `invalid`, or `unknown`, with exact cited spans
  and missing requirements. Reject missing fields, string booleans, nonfinite scores,
  contradictory fields, and scratchpad JSON masquerading as a final verdict.
- Size/select source windows by required evidence and preserve headers/footnotes; do
  not silently infer omitted components from a head/tail transcript. Record coverage.

**Recovery terminal reward (not yet implemented).** Eligibility is binary; the
conditional valid reward remains graded by owner preference:

```text
C = task-typed terminal assistant answer is correct
V = authentic actor-visible support + valid semantic/numeric proof

if no answer / malformed answer / C is false:              INVALID, R = 0
elif V is invalid:                                        INVALID, R = 0
elif V is valid:                                          VALID, R = graded_valid_score
else (verifier/infrastructure uncertainty):                UNKNOWN; retry, then exclude whole group
```

The recovery plan specifies the proposed graded formula and separates actor failure
from malformed judge proposals, logging loss and service failures. Its grading/rubric
revision must be frozen before a live run. Do not fall back to the old heuristic curve
or infer provenance from flat text when the new protocol is missing.

Infrastructure errors are **not** 0, 0.5, or a file-based 1. Retry the same immutable
rollout; if unresolved, exclude/quarantine the whole sibling group under a documented
policy and log the selection effect. This requires integration with reward resolution
and batch assembly: do not return `None`/NaN to a manager that expects a scalar and
silently converts errors to zero. Persistent ambiguous gold should remove the task.
An agent failing to retrieve/cite evidence is an ordinary invalid outcome, not a way to
opt out of learning by inducing `unknown`. Judge outages must never increase reward.

Keep duplicate calls, compute usage, lengths, and costs as telemetry initially. Add an
explicit, separately tested efficiency objective only after grounded accuracy improves;
small success bonuses/penalties can dominate all-success groups after normalization.

### 6.5 Required reward-validation suite

Build separate development and locked validation fixtures from **non-Pro** questions,
with independent labels and matched variants. Include natural stochastic rollouts and
hand-constructed counterexamples; validate group ordering as well as individual labels.

| Family | Required behavior |
|---|---|
| Correct answer + complete valid proof | Accept, including equivalent alternative bulletins |
| Correct number + wrong row/category/period/unit/vintage | Reject even when numbers coincide or round identically |
| Correct number + missing component/header/footnote | Reject absent required support; reserve unknown for verifier/ledger failure, not an omitted required input |
| Wrong answer + valid retrieval | Terminal 0; classify arithmetic/formatting error separately |
| Answer candidates / reversed lists / duplicated slots / scientific notation abuse | Strict answer handling, not substring credit |
| Fake tool output in reasoning or compute stdout; failed gold-file read | No authenticated evidence credit |
| Evidence deletion, unrelated replacement, and middle-of-trace removal | No invented support from agent explanations or the reference answer |
| Padding, confident prose, repeated citations, injected evaluator instructions | Invariance to irrelevant style; reject instruction injection |
| Legitimate algebraic shortcut or published aggregate | Accept valid proof of the requested claim without demanding every reference atom |
| Malformed judge JSON, disagreement, timeout, outage | Typed unknown/error path; never fail-open success |
| Same episode through offline and actual training serialization | Same evidence, correctness, reward status, and scalar reward |

For natural labels, use two blinded reviewers and adjudicate disagreements; source
pages and a deterministic recomputation are evidence, not the training judge's verdict.
Repeat judging on a subset to quantify instability. Hold out canary families from
prompt tuning and re-test on fresh on-policy rollouts after each selected pilot stage.

**R-gate first pass (air/79, run 340221642696128, 2026-09-13).** A 9-case labeled probe
(`scripts/officeqa/make_rgate_fixtures.py` → `rgate_adversarial.jsonl`), each committing
the correct number so only the judge stands between it and a positive, graded by the real
GLM-5.3 TP16 judge on the WHOLE trajectory. The saved artifact is **8 resolved + 1
unknown**, not 9/9: RG06's `lucky_wrong_source`/route-0.30 verdict was still recorded as
`unknown` because it predates the parser's believe-and-cap refinement; replay is required.
The judge's reasons did identify the planted total-vs-component, wrong-period,
unsupported-guess, fabricated-output, and missing-component routes. **RG07's valid
alternative bulletin was accepted but discounted to 0.925**, so do not claim alternative
sources are penalty-free. Only three distinct questions and 281–771-character trajectories
were exercised. This is a wiring/behaviour smoke, **not** the §6.5 statistical gate (≥150
independent negatives, realistic/on-policy rollouts, false-accept upper bound ≤2%), which
remains required. Records: `officeqa_pilot_records/rgate_scores.jsonl`.

**Expanded R-gate — finalized after air/82 attempt 4 (2026-09-14 UTC).**
All reviewed attempts are terminal. Attempt 1 (`878119239646411`) failed on a scorer
import bug after judge startup. Attempts 2/3/4 completed scoring, wrote reports, and
failed their configured thresholds; nonzero job exits were deliberate gate failures.

| Run | Bundle | Labeled controls accepted | Labeled negatives accepted | Reported case upper95 | Result |
|---|---:|---:|---:|---:|---|
| 657777974855885 | 317 | 78/80 | 121/220 (55.0%) | 60.668% | FAIL |
| 591895497446045 | same 317 | 63/80 | 72/220 (32.73%) | 38.312% | FAIL |
| **543029753940588** | **339** | **16/80 (20%)** | **5/242 (2.066%)** | **4.295%** | **FAIL** |

Attempt 4 has 11/339 unknown rewards, 0/17 nonzero wrong-answer rewards and a 7.414%
base-ID upper bound. Its report was generated at 2026-09-14T05:54:57Z. Of 62 scored
control rejections, **55 came from literal gold-in-quote matching**, four from period
checking, two from negative judge verdicts and one from anachronism; only 1/26
alternative-source controls was accepted. The earlier frozen-verdict CPU replay showed
18/80 acceptance under v2.1; that was an ablation, not the live result (16/80).

**These are metrics against uncertified labels, not reliable judge error rates.**
The review refuted the generator's claim that a mutation automatically determines the
label. Literal-answer deletion leaves operands, unrounded values and sometimes full
supporting search snippets. Some A controls are impossible backward-dated renames.
R/N mutate early occurrences while later correct reads survive. D can change a listed
file but leave the actual supporting alternative untouched. T conflates wrong answers,
abstentions and formatting errors with unsupported retrieval. Answer-correct G traces
were not independently certified as grounded; all underlying 246 traces contain an
output at the historical 3,000-character recording cap (1,987/3,335 outputs).

The five remaining accepted negatives in attempt 4 are reviewed individually in the
archive: UID0002_N2 retains a later correct row; UID0148_T was benchmark-selected as
wrong despite correct numeric/list values and existing calculations; UID0204_T retains
the reported 1.47 and 1.3 trillion inputs supporting 0.17. UID0189_R2 exposes missing
source-period coverage despite a credited median; original actor visibility is unknown
because of logging loss. UID0122_T requires category/shortcut adjudication: CPI scaling
cancels, but euro+yen gives 0.953 pp whereas adding receivables gives 0.946 pp. Judge
prose is not a verified expression. Do not automatically relabel these to make a pass.

The current checker also has independently reproduced defects: compute stdout can be
laundered into evidence after an unrelated genuine read; fake flat markers earn credit;
read-only structured/flat episodes disagree; task units/percent semantics are incomplete;
file count is not operand count; generic year and quote-string matching rejects valid
proofs. Existing 12/43/18 test suites pass despite these problems.

Both bundles have **139 nominal negative base IDs**, not 220/242 independent questions;
some handbuilt IDs share facts. Even 0/139 has an exact one-sided upper of 2.132%.
The runner currently enforces the case bound and can false-pass missing/duplicated or
NaN scores. Recovery R7/R9 must certify labels/views, reject invalid result sets,
separate unknown from verified rejection, lock development/validation splits, and enforce
a defensible independent-unit bound. The current suite includes 63 hard UIDs (111 cases),
so training disjointness is not an untouched evaluator-development claim.

**Unknown handling — partial legacy mechanism, not whole-group exclusion.**
The -1.0 sentinel and sitecustomize wrapper zero advantages/returns; activation was seen
in the answer-mode smoke, but actual unknown groups were not exercised. The pinned
outer reward manager returns ordinary 0.0 on timeout, bypassing the sentinel. KL loss
(the smoke uses coefficient 0.01) and denominator effects are not removed by zeroing
advantages. Recovery R8 must preserve typed outcomes and admit only fully resolved
sibling groups before concat/balancing/losses, with bounded refill and backpressure
credit handling. Otherwise dropping groups can deadlock the 16-group async sync.

**Immediate next action:** implement the recovery plan, not another full prompt-tuning
run over this bundle. Reports, exact-hash bundles, score files, current-code/upstream
snapshots, final run statuses and portable CPU reproducers are preserved additively in
`officeqa_pilot_records/rgate_review_2026_09_14/`. The owner retains a graded reward and
full GLM-5.3 TP16; the repaired typed proof/authority/admission implementation is pending.

**Proposed full-scale gate:** all deterministic exploit/contract fixtures pass;
≥95% acceptance of valid proofs; ≥98% rejection of invalid-but-answer-correct proofs;
report uncertainty and require the one-sided 95% upper bound on false acceptance to
be ≤2%. With zero errors this needs about 150 independent negative cases; many
mutations of one question are not independent. A 200–400-example starter suite may
need expansion to meet that confidence requirement. Report unknowns/coverage separately
and do not improve apparent accuracy by hiding difficult cases as unknown. These are
proposed scale gates, not a guarantee against adaptive exploitation by a trained policy.

### 6.6 Judge serving and throughput

Retain the historically exercised `air/52c`/`air/73` recipe: full GLM-5.3 TP16 across
two nodes; `serve_judge.sh` creates a private Ray cluster; per-node NVMe staging was
reported as 704 GB at ~3.4 GB/s. Historical flags: `--reasoning-parser glm45`,
`--tool-call-parser glm47`, bf16 KV, CUDA graphs on, `--disable-custom-all-reduce`,
Ray 2.48.0. The pilot used `reasoning_effort=high`, `JUDGE_MAX_TOKENS=10240`,
`JUDGE_TIMEOUT=600`, and concurrency 8. Pin the actual image/model/config used rather
than assuming these model-specific behaviors generalize across revisions.

For the proposed cascade, approximate demand is:

```text
judge requests/sec = rollout completions/sec × strict-correct rate × unresolved-semantic fraction
```

Measure this at **projected improved-policy accuracy**, not only at the base pass rate.
Record queue age, p50/p95/p99 latency, tokens, judge utilization, cost, and conditional
error/parse rates **among requested judgments**. Current `judge_ok=1` on skipped wrong
answers can hide poor judge availability. Use backpressure and consistent inner/outer
timeouts; freeze/cache verdicts by complete evidence, question, and verifier-version hash.
Do not silently switch effort, prompt, or reward policy during a run.

---

## 7. Sequencing and decision gates

```text
M: measurement + tool contract ─┐
S: isolation + provenance ──────┴─> frozen base and oracle diagnostics
                                      │
D: 100–300 gold tasks / splits / curriculum ──> R: reward validation
                                      │                 │
                                      └─────────────────┴─> L: small controlled learning
                                                               │
                                           T: throughput/staleness + scale decision
                                                               │
                                           E: dev-selected, frozen final evaluation
```

| Gate | Evidence required to pass | Stop / next action if it fails |
|---|---|---|
| **M — measurement** | Reconciled per-question baselines; pinned scorer; substantive coverage metrics; faithful actor-visible logs; shared train/eval controller tests | Fix harness/representation and re-baseline; do not call a harness gain an RL gain |
| **S — isolation** | Compute cannot read host gold/secrets or contact network; time/memory/output limits kill execution; observations authenticated; no cross-episode state/stdout contamination | Block any policy optimization until repaired |
| **D — data** | Small gold bank passes semantic/source-view/derivation audits; declared train/dev/test fact split; no unresolved label ambiguity; sufficient actual mixed-outcome groups | Improve task construction, demonstrations, or curriculum rather than bulk generation |
| **R — reward** | §6.5 contract, false-accept/false-reject, coverage, and real-serialization tests pass | Keep judge diagnostic-only; do not ship v2 as the grounded treatment |
| **L — learning** | Small control experiment improves independent dev metrics beyond harness/SFT controls, without canary regression | Diagnose signal/exploration/data mismatch; stop scale-up on judge-score-only gains |
| **T — throughput** | Judge/rollout capacity at projected correctness; complete groups; measured policy lag and importance-ratio health; acceptable cost per useful update | Reduce lag, repair queueing, or improve verifier cascade before increasing cluster size |
| **E — evaluation** | Frozen checkpoint selected without Pro hill-climbing; paired results/CIs/costs; untouched confirmatory set for transfer claims | Report exploratory results honestly; do not relabel exposed questions as untouched |

A quick small-bank overfit smoke may precede the full statistical R gate **only** on
manually/deterministically certified tasks without unvalidated judge reward. Passing
that smoke proves wiring, not generalization. The large-run permission remains gated.

---

## 8. Training data, curriculum, and evaluation design

### 8.1 Gold must be semantically correct and observable

A canonical atom should include at least:
`concept/series, entity/geography, unit/scale, nominal-or-real basis, period type,
period, reporting vintage, qualifier/footnote, value, document/page/table/cell provenance`.
Store hierarchical header paths and the original cell text; do not infer semantics from
numbers or filenames alone. Define revision/alias equivalence explicitly.

The current HTML parser loses parent colspan context: a toy two-level header
`Army → {Actual, Budget}; Navy → {Actual, Budget}` becomes
`Army > Actual | Budget | Navy > Actual | Budget_2`.
Preserving numeric strings is not preserving table meaning. Fix and test rowspan,
colspan, body row-header `<th>` cells, OCR signs/footnotes, missing-versus-zero values,
and multi-page header continuation before treating the transformed corpus as certified.

Independently inspect original page images/PDFs for a stratified sample and ambiguous
cells; three models reading the same corrupted HTML can agree on the same error.
Use arithmetic/accounting invariants where applicable, but do not assume rounding or
historical revisions preserve every identity exactly.

For every training task, verify both:
1. The question specifies a unique interpretation/operator, required units, periods,
   and rounding/statistical convention; Python correctly computes that interpretation.
2. A solver using the **actual actor-visible tool interface**, without gold locations,
   can obtain the supporting data. An answer present only in offline JSON is not enough.

Start with **gold only**. Quarantine unresolved silver data; introduce it later as a
separate noise/benefit ablation, with explicit sampling/loss weights rather than a
per-question reward multiplier erased by GRPO normalization.

### 8.2 Solve the exploration bottleneck rather than inventing a style reward

- Diagnose on development questions with nested assistance: full retrieval → oracle
  file → oracle table/header → correct operands. Improvements between stages localize
  retrieval, interpretation, and arithmetic failures. Oracle-assisted numbers are
  diagnostics, never the headline benchmark result or hidden eval assistance.
- Fix the tools before scaling RL: accurate `next_start_line`, whole rows with headers,
  stable table/span IDs in search results, explicit regex mode, and predictable truncation.
  Ensure search snippets surface useful content rather than mainly document/date prefixes.
- Build a small set of verified demonstrations for query formulation, FY/CY/vintage
  disambiguation, row/column binding, computation, and timely finalization. Compare SFT-only
  against RL instead of assuming RL must learn the basic interface from sparse reward.
- Curriculum: single-cell lookup → several values in one table → multi-period/cross-file
  composition → financial/statistical interpretation and adversarial near-neighbor rows.
  Mix in natural paraphrases, entity aliases, distractors, revisions, and footnotes;
  purely templated arithmetic is not representative of all Pro failures.
- Band by **verified-success** probability under stochastic rollouts, not just a
  permissive exact-answer metric. With independent success probability p and G siblings,
  mixed binary-outcome probability is `1 - p^G - (1-p)^G`; p=0.1 gives only ~34% at G=4.
  With eight trials, a truly p=0.1 task is observed all-fail ~43% of the time. Treat
  `M_TRIALS=8` as a noisy estimate, retain uncertainty, and refresh bands as learning changes.
- Monitor actual mixed-outcome groups and all-fail/all-pass fractions by operator/family.
  Do not manufacture learning signal by letting noisy route scores differentiate all-pass
  groups. Cap resampling costs and record the induced curriculum/sampling distribution.
- If exploration remains inadequate, test a **separate**, tightly bounded retrieval-credit
  or prefix-curriculum experiment using verified evidence coverage. Do not reward keyword
  hits, eloquent reasoning, or mere tool calls. Naively adding telescoping progress terms
  to an episode-summed GRPO scalar may add no useful credit assignment; per-step shaping
  requires a deliberate credit-assignment implementation and its own controls.

### 8.3 Leakage and generalization

Question-text deduplication is necessary but insufficient. Group split/audit by
canonical fact, reprinted-series aliases, table family, and operator/template family.
Two different questions can train on the exact facts used by a held-out question.
Distinguish **same-corpus new-question performance** from transfer to unseen facts,
new table layouts, and new corpora.

Generate candidates without benchmark access; perform contamination screening in a
separate audit stage without returning benchmark text or detailed matching hints to
the generator. Keep the public hard questions and this pilot's trace-derived examples
out of training, and log their existing development exposure.

Create an untouched confirmatory test before tuning: independently authored questions
with fact/series-level separation, and preferably a second document family. For a
memorization diagnostic, use isolated synthetic corpus variants where facts change
but question structure does not. Update repeated aliases and relevant derived totals
consistently, recompute gold, and verify that the answer follows the new evidence.
Do not mutate the public benchmark and present it as an official OfficeQA score.

### 8.4 Controlled experiments and reporting

**Capability decision before the next baseline:** either retain a clearly labeled
local-text-only setting, or add reproducible external-reference/visual capabilities
for the benchmark requirements. Apply the same tools/data access to every arm. Never
supply gold-specific external values or restrict retrieval to oracle sources in headline
eval. If external retrieval is enabled, prevent access to public benchmark answer
repositories and mirrored QA pages; prefer a versioned, general-purpose reference
corpus or allowlisted primary-data sources, and audit retrieved content for leakage.
Report the full 133-question result; any capability-defined subset is secondary and
must be defined independently of which questions the model gets right.

Minimum small experiment:

| Arm | Purpose |
|---|---|
| Base with repaired/frozen harness | Separates infrastructure gains from learning |
| SFT-only on verified demonstrations | Tests whether interface/termination learning explains the gain |
| Strict-answer-only RL | Establishes the cheapest defensible RL baseline; implement a real answer mode |
| Verified-support RL | Tests incremental grounding/robustness benefit against the answer-only control |

Use identical RL initialization, questions, rollout budgets, decoding settings, and
resource accounting for the two RL arms. If both start from SFT, say so and use the
same SFT checkpoint. Report comparisons at matched generated tokens/samples **and**
GPU-hours, because a large judge changes cost. Repeat promising arms across seeds before
making a strong claim. Start with conservative policy lag/partial-rollout settings;
then measure whether fully-async throughput preserves learning quality.

Choose the checkpoint and any hyperparameters on a separate development set. Freeze
that choice before final Pro/confirmatory evaluation. Report a paired interval and an
exact paired test (e.g. McNemar on base→trained wins/losses); use question/fact-family
cluster-aware resampling where related questions share evidence. Repeated decodes and
many mutations of a question do not create independent test questions. One Pro question
is ~0.75 percentage points; a small positive delta should not be oversold.

Final dashboard: pinned benchmark exact / 1% / 5%; strict typed accuracy; independent
grounded-correct rate; substantive-answer coverage; explicit abstention and missing/
invalid-final rates; correctness among substantive attempts; natural/forced finals;
turn/token/latency distributions; no-match and useful-evidence rates; arithmetic versus
semantic errors; cost per grounded-correct answer; paired wins/regressions and seed variance.
Use held-out human/independent audits to detect judge hacking rather than evaluating
training reward with the same judge and calling that success.

---

## 9. Risks and required instrumentation

| Risk | Required mitigation / measurement |
|---|---|
| Reward exploits from answer stuffing, units, list matching | Typed parser tests + pinned benchmark scorer; record raw terminal submission |
| Judge hallucinated support from omitted text or reference answer | Full evidence ledger, blind semantic stage, independent labels, coverage and canary metrics |
| Positive lucky floor / small rubric weights amplified by GRPO | Exact zero for invalid; graded valid reward with std-normalization OFF; inspect real group advantages and grade noise |
| Verifier outage becomes success or policy-induced reward avoidance | Retry/quarantine with explicit statuses, complete sibling groups, conditional failure and selection-bias monitoring |
| Alternative source falsely penalized, or revised data falsely accepted | Canonical semantic/vintage keys and valid alternative proofs; no file-only gate |
| Policy reads answer keys or poisons other samples | **Actual compute isolation**: no gold/host mounts, credentials, or network; per-execution CPU/memory/output limits and killable process/container |
| “Timeout” leaves execution running / concurrent stdout mixes | A daemon-thread join does not terminate work; replace global `redirect_stdout`/shared-module execution with isolated capture and termination |
| Gold bank inherits structural/OCR errors | Hierarchical parser tests, original-page audit, independent semantics, end-to-end source-view solvability |
| Sparse reward learns nothing; synthetic skills fail to transfer | Demonstrations, oracle diagnostics, diverse curriculum, actual informative-group rate, independent dev slices |
| Harness produces apparent learning | Frozen manifests, new paired baseline after every tool/scorer/controller change |
| Training sees less evidence or stops differently than eval | Installed-runtime parity tests: schemas, per-turn/episode limits, tool truncation, forced-final behavior, loss masks |
| Judge backlog biases async batches and increases policy lag | Backpressure; complete groups; log policy age, importance ratios, queue age and timeouts by length/success |
| Bulk synthesis consumes budget without validated labels/learning | Small gold-only pilot and staged scale gates; measure cost per accepted task/useful update |
| Repeated benchmark tuning creates an inflated transfer claim | Dev-only checkpoint selection; disclose Pro exposure; untouched confirmatory set |
| Broken GPU/transfer operations recur | Retain proven NCCL/Ray/save recipes, prewarm retrieval, and FUSE bulk transfer patterns |

**Sandbox probe (confirmed escape; bubblewrap implemented 2026-09-13).** The old AST and
audit-hook designs were both escaped; Python explicitly says audit hooks are not a
sandbox. `py_compute.py` now uses `bwrap`: no network; read-only root; masked
`/Volumes`, `/dbfs`, `/home`, `/root`, `/local_disk0`, `/mnt`; ordinary Python and the
scientific stack remain available; process timeout is killable; it fails closed unless
`OQ_COMPUTE_ALLOW_UNSANDBOXED=1`. CPU tests report 11 pass + 2 pandas-dependency skips;
direct probes confirmed corpus CSV, model config, home files, and the repo are invisible
inside compute. The v7 image was pushed/registered and df1 sandbox probe
510519807483794 succeeded; the later answer-mode smoke completed two updates. Re-run
sandbox/scientific-stack checks in any new patched candidate image; evidence authority
and group admission are separate unresolved boundaries.

**Specific parity checks (CONFIRMED against pinned v0.9.0 source 2026-09-13).**
ToolAgentLoop truncates the tool response by **characters** (`tool_agent_loop.py:533`,
`max_tool_response_length`, `tool_response_truncate_side` left/right/middle) — NOT tokens.
So the OfficeQA training YAML MUST set `rollout.multi_turn.max_tool_response_length` ≥ the
tools' own output size (read caps ~4,000 chars; grep can exceed that) — target ~6,000–8,000
— because eval feeds the tool output to the actor IN FULL (no loop-level clip after the
2026-09-13 fix). A small default (e.g. 512) would starve the training actor of evidence
that the eval actor sees, breaking parity. Termination is by `response_length` (tokens)
and `max_assistant_turns`/`max_user_turns` (lines 286–290) with **no** prefix-forced
final-answer turn like eval — a capped training rollout commits no answer → strict-gate 0
(a legitimate "ran out of budget" negative, but a distribution difference vs eval to log,
or to close by adding a forced-final to the training loop). The OfficeQA training YAML now exists and its answer-mode smoke completed two updates,
but that did not validate grounded parsing of the decoded solution. The review reproduced
read-only structured/flat reward disagreement and forged-marker credit; pinned
RateLimitedRewardManager uses `skip_special_tokens=True`. Recovery must carry trusted
structured events through the installed loop/manager, unify termination/view budgets,
and test masks and all-loss group exclusion. A new parsing regex is not parity proof.

Required per-rollout fields include: strict/benchmark correctness, verifier status,
coverage and missing requirements, judge requested/used/parse/error status, semantic
reason codes, prompt/group/policy IDs, termination reason, budgets, actor-token loss
mask versus observation tokens, and reward/judge/corpus versions. Inspect mask placement
at truncation and forced-final boundaries; do not train on tool outputs as actor tokens.

---

## 10. Immediate implementation backlog (ordered)

**Authoritative current backlog:** `docs/officeqa_rgate_recovery_plan.md`, packages
R0–R11, file-level map, red tests, acceptance gates and GPU ladder. R0 evidence/docs are
complete in this handoff; recovery implementation R1 onward is **not implemented**.
Start R1 (promotion guard/red regressions), then R2 contracts; do not relaunch air/82.
See `docs/officeqa_rgate_handoff.md` for exact commands and pending owner decisions.

The reconciled historical checklist below records earlier work, not permission to
train. Green legacy unit tests are insufficient for the newly reproduced defects.

1. [~] **Freeze/reconcile measurement.** Local parts DONE 2026-09-13:
   `scripts/officeqa/measure_traces.py` emits per-difficulty coverage (substantive/
   abstain/missing), termination (reached-cap vs truncated, now distinct), grep efficacy,
   and correctness under THREE scorers at exact tolerance, plus per-UID drift and an
   immutable manifest. The benchmark scorer is **pinned**: upstream `reward.py` vendored
   byte-identical as `officeqa_reward_upstream_pinned.py` (sha256 `0d91698c…`, asserted at
   run time). Reproduced §2.1 exactly; the sole 3-way drift is UID0148 (upstream's list
   parser accepts the ambiguous `28,2444.28`; the legacy selector rejects it while
   the current strict numeric/list parser accepts the values). air/71↔air/72
   reconciliation DONE (`reconcile_runs.py`): the runs did NOT reproduce per-UID (76/246
   preds diverged; full-set McNemar 37 discordant; hard-set 18 discordant with
   illustrative paired SE≈3.2pp) though aggregates match — repeated runs and paired
   same-question analysis are required (§2.1). `reconcile_runs.py` now refuses missing/
   duplicate UIDs and differing gold/difficulty labels instead of silently pairing bad
   data. STILL OPEN: decide local-vs-upstream as the official benchmark metric.
2. [~] **Close deterministic reward exploits.** Earlier 43/43 grammar/assembly tests
   passed, and removal of the positive lucky/file-fallback reward is retained. **Reopened
   by the 2026-09-14 review:** task units/percent semantics, trusted terminal extraction,
   compute/prose/marker authority, quote matching, semantic/completeness consistency
   and real serialization remain broken. Recovery R1/R2/R4/R5/R6/R8 are required;
   do not label this tranche complete because the old tests remain green.
3. [x] **Isolate compute.** DONE 2026-09-13: real `bwrap` boundary replaces the escaped
   audit-hook approach; masked mounts/no network/fail-closed; 11 pass + 2 dependency
   skips; direct corpus/model/home/repo invisibility probes pass. v7 is pushed and
   registered; df1 `air/80` run 510519807483794 proves the compute-tool bwrap variant
   (without nested `/proc`) runs and denies network. Remaining verification belongs in
   the first OfficeQA training smoke, not a separate image rebuild.
4. [~] **Repair observable evidence.** Judge-visibility half DONE 2026-09-13: removed
   the 3,000-char trace clip (record the FULL actor-visible tool output,
   `eval_officeqa_agentic.py`) and the judge now sees the WHOLE trajectory
   (`build_user_prompt` no longer head/tail-truncates; the reward fails closed to
   `unknown` above `OQ_JUDGE_TRAJ_MAX` rather than grading a partial view;
   `JUDGE_MAX_MODEL_LEN` raised to 131072). STILL OPEN: read cursor/whole-row clipping,
   header-meaning preservation, and stable observation IDs / evidence-ledger capture.
5. [ ] **Implement the smallest proof verifier and shared episode contract.** Start
   with lookup/sum/difference/ratio, canonical evidence bindings, and deterministic
   arithmetic. Run actual ToolAgentLoop/reward-manager replay parity tests, including
   forced finalization and loss masks. Function tools do not automatically provide
   per-episode state; integrate at the controller or an appropriate stateful tool boundary.
6. [ ] **Certify a real-easy task bank plus demos/dev/canaries.** Begin with 20–30
   existing easy questions and independently audited proofs/views, not bulk synthesis.
   Fix train/val overlap, freeze fact/alias splits and quarantine ambiguous gold.
   A full >=150-independent-case statistical claim needs additional suitable tasks;
   113 easy questions plus repeated mutations cannot supply that independence.
7. [~] **Rebuild reward validation, not another prompt-only loop.** All air/82 attempts
   are terminal. Attempt 4 (`543029753940588`) scored 339 cases and failed: controls
   16/80, labeled-negative accepts 5/242, case upper95 4.295%, base-ID upper 7.414%.
   Fifty-five control rejections came from literal-value absence; labels also contain
   surviving valid evidence and fake alternate sources. The archived 317/339 bundles
   are development diagnostics, not independently certified statistical validation.
   Implement R7/R9 certification, integrity/cluster/coverage checks, then fresh views
   and the staged GPU ladder. Sentinel activation is not true whole-group exclusion:
   outer timeouts and KL/denominator effects require R8 admission before losses.
8. [~] **Run a short learning control experiment.** OfficeQA integration smoke
   (`air/77`, run 255793754949568) proved corpus staging, Qwen tool parsing, bwrap
   compute, the real reward function path, and clean fully-async completion. It also
   exposed a batch-sizing contract: fully-async requests 16 samples per sync but the
   8-question dataset terminates after 8 unique prompt rollouts. The 32-question rerun
   (run 805654108465557) then DID form a full 16-group sync and ran fwd/bwd, but the
   first optimizer step OOM'd in grad-norm all_reduce at 147k-token episodes
   (16 turns) -- and the exit guard false-passed it SUCCESS (veto patterns now cover
   NCCL/Cuda-failure/DistBackendError forms). **Rerun 616024033111491 (MAX_TURNS=8,
   73k budget) COMPLETED the first real OfficeQA optimizer steps: 2/2 global steps,
   2 full 16-group syncs, score mean 0.078 (10/128 sequences), advantages +0.75/-0.25
   (mean-baseline, std-norm off), pg_loss 0.0041, grad_norm 0.065, peak trainer memory
   52.4 GB, zero aborted episodes, quarantine patch ACTIVE in trainer + workers.**
   This proves answer-mode rollout/tools/reward/GRPO/Megatron update/param-sync wiring,
   NOT actual UNKNOWN-group exclusion. It is not a learning result (tiny LR, two steps),
   and `save_freq=-1` means this run is not proof of OfficeQA checkpoint writing/reload.
9. [ ] **Load-test at projected successful-policy demand.** Validate judge queues,
   end-to-end reward deadlines, async lag, group completeness, and cost before scaling.
10. [ ] **Scale only after the gates.** Expand operators/data, add silver only as an
    explicit ablation, then perform dev-selected final evaluation with paired statistics.

Suggested regression-test groups (new tests, not existing files):
- Answer shape/unit/rounding and mode contracts; malicious/malformed final tags.
- Evidence authenticity, failed reads/no-match grep, alternative-vintage equivalence,
  omitted components, alternate valid proofs, and deterministic recomputation.
- JSON schema/NaN/string-boolean/contradictory-verdict handling and outage monotonicity.
- Scalar reward **and actual GRPO advantage** fixtures, including all-fail/all-pass groups.
- Header rowspan/colspan, visible-span/cursor correctness, and lossless ledger replay.
- Sandboxing and concurrency; installed-container train/eval serialization/mask parity.

**Operational open items retained:** pin actual full-GLM-5.3 model/tokenizer/image/
prompt revisions, implement the typed loop/manager and admitted-group backpressure,
and verify checkpoint save→reload in the eventual OfficeQA job. A new question renderer
or external multi-provider panel is not required for the real-easy recovery tranche. OfficeQA smoke run 255793754949568 proved the clean
rollout/reward/tool path but not an optimizer update (8 unique prompts < 16-sample
sync); run 805654108465557 formed the batch but OOM'd the first optimizer step at
147k-token episodes and false-passed the exit guard (hardened since: NCCL/Cuda-failure/
DistBackendError vetoes). Commit reviewed code/docs only when requested; do not
silently commit the existing unrelated working-tree changes or overwrite pilot data.

---

## 11. Review provenance and primary references

Historical findings were measured on **2026-09-13**; the finalized **2026-09-14 UTC**
review adds complete air/82 attempt-4 results, exact-hash reconstruction/replay and CPU
probes of authority, parsing, gate integrity and the pinned reward manager's outer
timeout. The answer-mode GPU integration completed two real updates; the corrected
installed-runtime grounded/UNKNOWN/all-loss contract remains unvalidated. Complete
new provenance, raw scores, code snapshots and portable reproducers are in
`officeqa_pilot_records/rgate_review_2026_09_14/manifest.json` and its README.

Artifact SHA-256 values:

```text
officeqa_traces.jsonl
9f1e93c633fd043f0e1f607c6e5f545b16a5bdb13e2175ce885b15c09bfb858a

officeqa_grounded_scores_v1.jsonl
ae62aa834edeb1202e3030b46df8550ba7041179b0e555080e900f407229cb7c

officeqa_grounded_scores_v2.jsonl
07078ec71d7487fda116bd23edc12b9600fe005699e43a99b79e63a3f54b6fe3

Upstream OfficeQA reward.py snapshot downloaded/inspected during review
0d91698c87df6d889339aac36f63ae0966607f169890b0bf8b472b26bfe8138f
```

The inspected upstream scorer is now archived in the project as
`scripts/reward/officeqa_reward_upstream_pinned.py`; preserve its exact hash. Explicitly
record which reporting backend is used: changing the scorer is not learning, and the
benchmark selector must not assign semantic support labels.

Primary references checked during review:
- OfficeQA Pro paper, March 9, 2026, §2.2 and Table 1 (capabilities/budget comparison):
  `https://arxiv.org/html/2603.08655v1`
- Official OfficeQA scorer (mutable URL; use a pinned revision/hash for experiments):
  `https://raw.githubusercontent.com/databricks/officeqa/main/reward.py`
- verl v0.9.0 GRPO implementation (`compute_grpo_outcome_advantage`) and defaults:
  `https://raw.githubusercontent.com/volcengine/verl/v0.9.0/verl/trainer/ppo/core_algos.py`
  `https://raw.githubusercontent.com/volcengine/verl/v0.9.0/verl/trainer/config/algorithm.py`
- verl v0.9.0 ToolAgentLoop (turn termination, response clipping, tool lifecycle):
  `https://raw.githubusercontent.com/volcengine/verl/v0.9.0/verl/experimental/agent_loop/tool_agent_loop.py`
