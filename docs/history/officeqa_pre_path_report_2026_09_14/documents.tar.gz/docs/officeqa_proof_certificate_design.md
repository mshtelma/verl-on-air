# OfficeQA support-certificate design — "make the model declare its path"

**Status:** design proposal for owner sign-off (a D3-class decision in
`docs/officeqa_rgate_recovery_plan.md`). Concretizes R2 §5.3 (SupportCertificate),
R4 (trusted ledger) and R5 (deterministic proof) into an actor/verifier contract.
Not implemented. No change to R1 (the promotion guard + red inventory stand either way).

## 1. Problem

Our hardest check is *did the model follow a correct path* — read the right table/row/
period, use the right operands. Today a free-form GLM judge infers the path from prose,
and the 2026-09-14 review proved it **confabulates** support (F05; 55% false-accept in
air/82 attempt 2). We want the path to be a **checkable object**, not a judge's guess.

## 2. Core principle: the certificate is an interface, not a guarantee

A path-object or `cite(...)` call is a **claim**. Under GRPO the policy optimizes whatever
scores, so rewarding a self-reported path just moves the exploit from "match the number"
to "fake the path" — unless every claim resolves against something the policy cannot forge:

- **Controller-owned ledger (R4).** Observation IDs are *issued by the controller* when it
  executes a tool and delivers the result into the model's context. The actor may only
  *reference* them, never mint them. A binding's cited value is read from the **ledger**,
  not from a number the actor typed.
- **Deterministic proof engine (R5).** The proof plan is recomputed over ledger-resolved
  values; the result must equal the typed answer. `print(gold)` and unused-input algebra die.
- **Header/period context (R3 table IR).** To check "*correct* table/row/period", the binding
  carries the cell's header path + period + unit, and code confirms they match the task
  requirement and were visible in the same delivered observation.

The object makes verification **mechanical**; the ledger+engine+header-paths make it **sound**.
This rides on R2/R3/R4/R5 — it does not replace them.

## 3. Two authorship modes (NOT interchangeable)

| | **Actor-emitted** (this idea) | **Judge-proposed** (recovery plan's first version, D3) |
|---|---|---|
| Actor interface | new: `submit_answer(...)` + `cite(...)` tools | unchanged: just `<FINAL_ANSWER>` |
| Judge cost | only for the semantic residue | one GLM-5.3 pass per correct answer to propose bindings |
| Trains grounding? | **yes** — reward shapes "cite real cells that prove it" | no — only filters |
| **Malformed/forged path** | **INVALID → 0** | **UNKNOWN → retry/quarantine** |
| Exploration | hard cold-start → needs SFT demos/curriculum | easy (no new output language) |

The bold row is the safety-critical distinction: a malformed **actor** certificate is a plain
zero (so the policy can't emit garbage to *induce* UNKNOWN and dodge negative reward);
a malformed **judge** proposal is UNKNOWN (the judge's mistake is not the actor's fault).
Never mix the two contracts in one run.

**Recommended sequencing:** ship judge-proposed first (repairs the reward without a new
output-language exploration problem) = `officeqa_proof_v1`; flip to actor-emitted once the
ledger+engine are proven and SFT demos exist = `officeqa_proof_v2`. **The verifier is shared;
only who authors the certificate changes.**

## 4. Actor tool contract (actor-emitted variant)

The controller tags every successful tool result with a stable, **episode-scoped** observation
id and surfaces it to the actor, e.g. a read returns:

```
[obs o7] treasury_bulletin_2004_09.txt  lines 120-146 of 512   (col header: FY2004, unit: USD)
r17 | Gross receipts, liquid fuels | 302,665,000
r31 | Refunds, liquid fuels        |  47,976,000
```

- `cite(observation_id, cell, note?)` — optional, during the episode; the controller validates
  the reference *at call time* (resolves? in-scope? delivered?) and annotates it. This is the
  "special tool call" — it makes forgery detectable immediately, not just at scoring.
- `submit_answer(final_answer, answer_kind, unit, proof_plan, bindings)` — the **only** accepted
  commitment channel (a trusted terminal event, R4.2). `<FINAL_ANSWER>` is still written for
  benchmark-scorer parity; the certificate lives in this separate action (plan §6.4.A).

## 5. Certificate schema (what the verifier consumes; aligns with R2 §5.3)

Actor emits the minimal object; **the verifier fills `semantic_checks`, `semantic_grade`,
`decision`** — the actor never asserts those.

```json
{
  "schema_version": "officeqa.support.v1",
  "final_answer": "254,689,000",
  "answer_kind": "quantity", "unit": "USD",
  "proof_plan": "gross_minus_refund",              // must be in TaskSpec.allowed_proof_plans
  "bindings": [
    {"slot": "gross",  "observation_id": "o7", "cell_id": "r17c2",
     "context_refs": {"row_header": "Gross receipts, liquid fuels", "col_header": "FY2004", "unit": "USD"}},
    {"slot": "refund", "observation_id": "o7", "cell_id": "r31c2",
     "context_refs": {"row_header": "Refunds, liquid fuels", "col_header": "FY2004", "unit": "USD"}}
  ]
}
```

## 6. Verification pipeline (deterministic first; judge only for residue)

1. **Answer gate (R5.1, `strict_answer` + F06 fix):** strict-parse `final_answer`, compare to
   gold in arity/order/unit/value (Decimal). Fail → INVALID 0.
2. **Reference resolution (R4/R5.2):** each `observation_id` resolves in *this* episode's ledger
   to a **successfully delivered** observation; `cell_id` exists in its R3 structured view; cited
   value == ledger value. Forged/cross-episode/undelivered → INVALID 0 (actor) / UNKNOWN (judge).
3. **Context & semantics (R3/R6):** cited cell's header path/period/unit match the TaskSpec slot.
   Code settles unit + exact period; a **blinded** judge settles only the residue (category/alias/
   vintage) from authenticated observations — never gold, prose, or compute stdout. A false
   semantic flag cannot coexist with a positive.
4. **Derivation (R5.3–5.4):** run `proof_plan` (allowlisted operators) over ledger-resolved slot
   values; enforce coverage (a median needs its full required period set); recomputed result must
   equal the typed answer. Fail → INVALID 0.
5. **Grade (D2):** VALID → `R = clip(0.30 + 0.50·semantic_grade + 0.20, 0, 1)`, trajectory-quality
   fixed at 1.0 initially; a valid alternative source/proof gets the **same** grade as the
   reference. INVALID = exactly 0. Verifier/infra failure = UNKNOWN → retry, then whole-group
   quarantine (R8). Requires `algorithm.norm_adv_by_std_in_grpo=False`.

## 7. Failure taxonomy (INVALID vs UNKNOWN)

| Situation | Actor-emitted | Judge-proposed |
|---|---|---|
| answer wrong/absent/malformed | INVALID 0 | INVALID 0 |
| binding refs unissued/forged/cross-episode obs | **INVALID 0** | UNKNOWN |
| cited value ≠ ledger value | **INVALID 0** | UNKNOWN |
| proof recomputes ≠ answer, or incomplete coverage | INVALID 0 | INVALID 0 |
| malformed certificate schema | **INVALID 0** | UNKNOWN |
| ledger missing / verifier crash / judge outage | UNKNOWN | UNKNOWN |
| answer ok + refs resolve + proof checks + semantics ok | VALID graded | VALID graded |

## 8. Worked anchors (why this fixes the review's false-accepts)

- **UID0002** — early cell swapped, correct 507 row survives later. We check the **cited** binding,
  not the whole trajectory; citing the real surviving row → VALID, and the earlier misleading read
  is irrelevant (D1: a misleading early lookup doesn't invalidate a later supported answer).
- **UID0189** — two 13-month medians credited from 2 quoted rows. The median binding must cite the
  **full** required period set; 2 rows fail coverage (R5.4) → INVALID. Mechanical, where the judge
  waved it through.
- **UID0122** — euro+yen (0.953pp) vs euro+yen+receivables (0.946pp) are **different `proof_plan`s**;
  category membership is adjudicated by R3 header hierarchy + judge residue, not by "the number matches".

## 9. Dependencies and open owner decisions

- Depends on: R2 (schema), R3 (table IR + header paths), R4 (ledger + controller-issued obs ids +
  `verl_agent_loop.py`), R5 (proof engine), R6 (blinded judge for residue), R8 (whole-group admission).
- Owner decisions to lock: (a) authorship = judge-proposed first, then actor-emitted (recommended);
  (b) the INVALID-not-UNKNOWN rule for actor certificates; (c) D2 grade formula; (d) whether the
  actor commitment moves to a `submit_answer` tool now (helps R4.2's trusted terminal channel).
- Link this doc from the recovery plan's R2/D3 once the authorship decision is confirmed.
